# Handoff For Next LLM - 2026-06-20

Date: 2026-06-20
Repo: `/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/WorkingRCX`
Audience: next Codex/LLM operator continuing the WorkingRCX queue.

## Operating Contract

Before substantive work, follow repo protocol:

1. Read `FOUNDER_SESSION_BOOTSTRAP.md`.
2. Re-verify volatile state from `STATUS.md`, `TASKS.md`, `CHANGELOG.md`, `reports/README.md`, and `git status --short`.
3. Prefer repo-native pipeline, launcher, builder, commit executor, and recovery surfaces. Manual fixes are allowed only as bounded unblocks, and must either include a same-wave structural fix or leave a precise next-wave automation packet.
4. Keep orchestrator, implementer, reviewer, pager, autoping, and tmux roles conceptually separate. Do not assume changing one should implicitly rewrite the others unless the easy-switch wave implements that contract.
5. Preserve user/WIP state. Do not drop, pop, reset, clean, or blindly apply stashes.

The user explicitly asked: after the current pipeline merged, stop and provide this handoff instead of starting the next wave.

## Current Stop Point

The current pipeline has merged. Do not start another wave unless the user asks.

Merged PR:

- PR #1132: `docs: refresh active queue with WIP preservation work`
- Merged at: `2026-06-20T18:00:33Z`
- Merge SHA: `d2d163660f338a347bc92d2bfbc32a4631456099`
- Head SHA before merge: `95c1b7d582d8811c1290ef857ecb864cf0657a44`
- Commit executor status: success

Final commit executor output:

```text
[commit-executor] Status: success
[commit-executor] Steps: validate_inputs, ensure_feature_branch, ensure_tracker_note, stage_files, collect_and_stage_indicator, refresh_commit_packet_truth, build_and_run_supervisor, validate_receipt, run_pre_commit_script, git_commit, run_pre_push_script, git_push, wait_ci, ensure_review_clear_and_merge, post_merge_cleanup
[commit-executor] PR: #1132
[commit-executor] Merge SHA: d2d16366
```

PR #1132 checks all passed:

- `test`
- `green-gate`
- `orbit-dot`
- `orbit-provenance`
- `engine-run-schema`
- `orbit-svg`
- `orbit-index`

## Current Repo State

Main worktree:

- Path: `/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/WorkingRCX`
- Branch: `jabramsja/workspace-2026-06-04`
- HEAD: `d2d16366`
- `origin/dev` / local `dev`: also at `d2d16366`

Current `git status --short --branch --ahead-behind` on main:

```text
## jabramsja/workspace-2026-06-04
?? reports/deferred/non_blocking/flaky-audit-fast-parallel-load-2026-06-08.md
?? reports/deferred/non_blocking/flaky-js-parity-no-json-api-response-2026-06-08.md
?? reports/deferred/non_blocking/pager-claude-quickack-receiver-design-2026-06-17.md
?? reports/deferred/non_blocking/preflight-step17b-pgrep-native-install-enumeration-2026-06-09.md
```

Important: earlier tracked main-worktree WIP is not currently live in the main worktree. It is preserved in stash and in the external preservation snapshot described below.

## What Was Done In This Session

### 1. Primary Fast-Forward / Tracked-WIP Preservation Fix Landed

Wave: `primary-ffsync-tracked-wip-preserve-2026-06-20`

Merged PR:

- PR #1131
- Merge SHA: `e1894d64`

Purpose:

- Fix commit executor primary-worktree fast-forward sync so tracked WIP does not cause Step 15b to skip or silently clobber user work.

Behavior implemented by that wave:

- Stashes exact tracked dirty paths only when a real fast-forward is pending.
- Checks overlap with incoming range.
- Restores non-overlap.
- Leaves overlapping WIP in an executor-owned stash with metadata.

Commit executor success evidence from that wave:

```text
[commit-executor] Status: success
[commit-executor] PR: #1131
[commit-executor] Merge SHA: e1894d64
```

### 2. Queue / Status Sync Landed

Wave: `active-queue-wip-preservation-sync-2026-06-20`

Merged PR:

- PR #1132
- Merge SHA: `d2d16366`

Files changed:

- `STATUS.md`
- `TASKS.md`
- `reports/control_plane/active-queue-wip-preservation-sync-2026-06-20_2026-06-20.md`
- `reports/control_plane/active-queue-wip-preservation-sync-2026-06-20_wave_config.json`
- `reports/l4_wave_indicators/active-queue-wip-preservation-sync-2026-06-20.json`

Bot remediation commit:

- `95c1b7d5`
- Touched only `TASKS.md`
- Purpose: clarify that the local `.rcx_wip_preservation/...` snapshot is not a committed canonical artifact until a future wave creates/records the preservation artifact in repo-tracked truth.

Current canonical queue lives in `TASKS.md` NOW section. Relevant line anchors after merge:

- `TASKS.md:675` starts `[ACTIVE-CODEX-AUTONOMOUS-QUEUE]`
- `TASKS.md:697` starts remaining execution order
- `TASKS.md:698` names `STRUCTURAL-NUMBERS-STAGE4-DESIGN-2026-06-19` as current next
- `TASKS.md:705` names WIP-preservation recovery
- `TASKS.md:714` names Stage0 decision/recovery
- `TASKS.md:720` names easy-switch propagation
- `TASKS.md:739` records the parallelization rule
- `STATUS.md:164-166` points at the same active queue and packet

### 3. External WIP Preservation Snapshot Created

External snapshot path:

```text
/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/.rcx_wip_preservation/20260620T171515Z
```

This is a local preservation artifact outside the repo working tree. It is useful evidence, but not canonical repo-tracked truth. The next WIP wave should either create a tracked preservation report or update the queue with a tracked artifact before treating it as authoritative branch state.

Snapshot includes:

- Main worktree status, staged/unstaged binary diffs, untracked lists/copies, recent log, HEAD bundle.
- Stage0 lane status and staged binary diff.
- Lane2 state at time of snapshot.
- Supplemental lane3 observability snapshot.
- Git stash preservation under:

```text
/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/.rcx_wip_preservation/20260620T171515Z/git-stashes
```

Stash preservation includes:

- `all-stashes.bundle`
- `stash-list.txt`
- per-stash `.patch`
- per-stash `.stat.txt`
- per-stash `.cat-file.txt`

### 4. Lane3 Preservation Gap Closed Locally

The first snapshot did not include lane3. A supplemental lane3 snapshot was added at:

```text
/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/.rcx_wip_preservation/20260620T171515Z/workingrcx_lane3_observability_20260619
```

Files there:

- `head.bundle`
- `recent-log.txt`
- `staged.diff`
- `status.txt`
- `unstaged.diff`
- `untracked.txt`
- `untracked.zlist`

Supplemental lane3 status captured in the snapshot:

```text
## jabramsja/pipeline-observability-live-root-2026-06-19...origin/dev [ahead 1, behind 34]
M  reports/control_plane/pipeline-observability-live-root-2026-06-19_2026-06-19.md
```

Current recheck after PR #1132:

```text
## jabramsja/pipeline-observability-live-root-2026-06-19...origin/dev [ahead 1, behind 37]
M  reports/control_plane/pipeline-observability-live-root-2026-06-19_2026-06-19.md
```

## Stashes And WIP To Protect

Current top stash:

```text
stash@{Sat Jun 20 13:25:39 2026} On workspace-2026-06-04: commit_executor:primary_ffsync_tracked_wip:fcd2f4425aad44d892465dd9115fc789
```

This is important. Do not drop it.

It contains tracked main-worktree WIP that used to be live before commit-executor post-merge cleanup. `git stash show --name-status stash@{0}` showed these paths:

```text
M .claude/rules/wave-protocol.md
M CLAUDE.md
M STATUS.md
M TASKS.md
M mu/tests/docs/test_docs_registry_agent_memory_exempt.py
M mu/tools/docs/docs_registry.json
M mu/tools/executors/executor_config.json
M mu/tools/observability/_pane_processes.sh
M mu/tools/observability/_pane_timeline.sh
M reports/control_plane/structural-numbers-gcd-2026-06-19_2026-06-19.md
```

Other stashes currently present:

```text
stash@{Sat Jun 20 01:54:35 2026} On structural-numbers-gcd-2026-06-19: gcd-packet-repair-marker-2026-06-20
stash@{Sat Jun 20 01:35:35 2026} On queue-status-sync-2026-06-20: queue-status-rootenv-duplicate-and-packet-refresh-2026-06-20
stash@{Fri May 29 02:11:11 2026} On ci-green-gate-js-metabolization-continuation-reuse-2026-05-28: codex-preserve-pipeline-scope-privateattr-tooling-2026-05-29
stash@{Fri May 29 02:11:06 2026} On ci-green-gate-js-metabolization-continuation-reuse-2026-05-28: codex-preserve-js-kernel-continuation-proof-2026-05-29
stash@{Fri May 29 01:32:32 2026} On ci-green-gate-js-metabolization-continuation-reuse-2026-05-28: codex-preserve-out-of-scope-p7w5-commit-2026-05-29
stash@{Fri May 22 12:53:53 2026} On n3-js-evidence-walker-runtime-authority-parity-2026-05-22: failed n3-js-evidence-walker-runtime-authority-parity pipeline artifacts before phase-a path repair
stash@{Sun May 17 14:25:59 2026} On dev: codex-startup-checker-local-fix-2026-05-17
stash@{Wed Apr 22 12:47:51 2026} On pipeline-agent-pager-transport-2026-04-22: phase-a-recovery-unblock-pager-2026-04-22
```

Recommended safe handling:

1. Do not run `git stash pop`.
2. Inspect with `git stash show --name-status stash@{N}` and `git stash show --patch stash@{N}`.
3. For `stash@{0}`, compare each path against `d2d16366` and recover only still-relevant non-conflicting edits.
4. If applying selected hunks, do it in a dedicated WIP-preservation/recovery wave, not opportunistically inside StructuralNumbers or easy-switch implementation.

## Worktrees

Current `git worktree list --porcelain`:

```text
worktree /Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/WorkingRCX
HEAD d2d163660f338a347bc92d2bfbc32a4631456099
branch refs/heads/jabramsja/workspace-2026-06-04

worktree /Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/workingrcx_lane1_castage0c_20260616
HEAD f074021973cc4289e14bea329136ca4c3efb483b
branch refs/heads/jabramsja/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16

worktree /Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/workingrcx_lane2_recoverygate58
HEAD d2d163660f338a347bc92d2bfbc32a4631456099
branch refs/heads/dev

worktree /Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/workingrcx_lane3_observability_20260619
HEAD e6ba365858b2ad6d086f08e8f7c31c2a4b608f17
branch refs/heads/jabramsja/pipeline-observability-live-root-2026-06-19
```

### Main Worktree

Current live dirty state:

```text
?? reports/deferred/non_blocking/flaky-audit-fast-parallel-load-2026-06-08.md
?? reports/deferred/non_blocking/flaky-js-parity-no-json-api-response-2026-06-08.md
?? reports/deferred/non_blocking/pager-claude-quickack-receiver-design-2026-06-17.md
?? reports/deferred/non_blocking/preflight-step17b-pgrep-native-install-enumeration-2026-06-09.md
```

Tracked WIP formerly present in main is now in `stash@{0}` and external snapshot.

### Lane1 Stage0 Worktree

Path:

```text
/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/workingrcx_lane1_castage0c_20260616
```

Branch:

```text
jabramsja/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16
```

Current status after PR #1132:

```text
## jabramsja/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16...origin/dev [behind 80]
M  TASKS.md
M  mu/host/js/core/bootstrap_core.js
M  mu/host/python/rcx_pi/selfhost/eval_seed.py
M  mu/tests/l4_gates/test_p7w4_structural_reduction_gate.py
A  mu/tests/l4_gates/test_stage0_content_addressed_collapse_gate.py
M  mu/tests/l4_gates/test_stage0_vm_cutover.py
A  reports/control_plane/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16_2026-06-16.md
A  reports/deferred/blocking/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16_phase_a_contradiction.md
A  reports/deferred/non_blocking/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16_bridge_nonblockers.md
A  reports/l4_wave_indicators/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16.json
```

Do not commit, rebase, or normalize this lane until the Stage0 contradiction is resolved.

### Lane2 Recovery Gate Worktree

Path:

```text
/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/workingrcx_lane2_recoverygate58
```

Current state:

```text
## dev...origin/dev
```

It is clean and at `d2d16366`.

### Lane3 Observability Worktree

Path:

```text
/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/workingrcx_lane3_observability_20260619
```

Current state:

```text
## jabramsja/pipeline-observability-live-root-2026-06-19...origin/dev [ahead 1, behind 37]
M  reports/control_plane/pipeline-observability-live-root-2026-06-19_2026-06-19.md
```

Preserve this work before any sync/rebase.

## Active Queue

The active queue is canonical in `TASKS.md`. Current order:

1. `STRUCTURAL-NUMBERS-STAGE4-DESIGN-2026-06-19`
2. `STRUCTURAL-NUMBERS-STAGE4-INT-FIRST-CUTOVER-2026-06-19`
3. `STRUCTURAL-NUMBERS-STAGE5-ORDINAL-TO-N-2026-06-19`
4. `WIP-PRESERVATION-DIRTY-WORKTREE-RECOVERY-2026-06-20`
5. `STAGE0-CONTENT-ADDRESSED-TYPEDISPATCH-DECISION-RECOVERY-2026-06-20`
6. `PIPELINE-EASY-SWITCH-PROPAGATION-2026-06-20`
7. `PIPELINE-FIX-33`
8. `PIPELINE-FIX-29`
9. `PIPELINE-FIX-31`
10. `PIPELINE-FIX-17`
11. `PIPELINE-FIX-34`
12. Lower-priority deferred research/cosmetic work only after the active queue clears.

Parallelization rule from `TASKS.md`:

- StructuralNumbers waves are sequential.
- Stage0 recovery is sequential with Stage0/runtime surfaces.
- Easy-switch, WIP-preservation, and narrow pipeline fixes may run in parallel only when implementation file ownership does not overlap and pipeline owns `TASKS.md` conflict handling.

## Detailed Plans By Queue Item

### 1. STRUCTURAL-NUMBERS-STAGE4-DESIGN-2026-06-19

Status: current next sequential StructuralNumbers wave.

Goal:

- Design Stage 4 integer-first numeric boundary after Stage 3 exact rationals landed.

Known completed predecessors:

- PR #1126: structural gcd Python, merge `ac7ca8ec`
- PR #1127: structural gcd JS parity, merge `da8e00a5`
- PR #1129: structural rationals, merge `20f2bf49`

Constraints:

- Do not jump straight to cutover.
- Keep design packet bounded.
- Preserve StructuralNumbers sequential order.
- Do not mix with WIP recovery or easy-switch tooling changes.

Suggested start:

1. Re-read `mu/docs/core/StructuralNumbers.v0.md` and existing StructuralNumbers tests.
2. Inspect Stage 3 rationals implementation and growth-cap tests.
3. Create a Phase A / design packet through launcher/builder, not by ad hoc docs only.
4. Validate docs/current-state tests and any design governance checks required by the packet.

### 2. STRUCTURAL-NUMBERS-STAGE4-INT-FIRST-CUTOVER-2026-06-19

Status: blocked on Stage 4 design packet.

Goal:

- Implement the integer-first boundary after the design packet defines exact scope.

Constraints:

- Must follow design wave.
- Must preserve Python/JS parity.
- Must not increase host-semantics ratchet.
- Must update focused StructuralNumbers gates.

### 3. STRUCTURAL-NUMBERS-STAGE5-ORDINAL-TO-N-2026-06-19

Status: blocked on Stage 4 cutover.

Goal:

- Implement von-Neumann ordinal to binary `N` bridge.

Constraints:

- Sequential after Stage 4.
- Must maintain structural-purity proof limits.
- Do not use host numeric shortcuts as semantic destination.

### 4. WIP-PRESERVATION-DIRTY-WORKTREE-RECOVERY-2026-06-20

Status: queued. Important before any work that mutates dirty lanes.

Goal:

- Turn local preservation into a tracked, reviewable recovery plan.
- Reconcile main stash/WIP, lane1 staged work, lane3 dirty work, and shared stashes without losing important work.

Why this matters:

- The main tracked WIP is no longer live; it is in `stash@{0}`.
- The external preservation snapshot exists but is not committed/canonical.
- `TASKS.md` now explicitly says no concrete preservation snapshot is current in branch/worktree until a corresponding artifact is added and the queue item points at it.

Recommended approach:

1. Create a dedicated preservation/recovery wave.
2. Use a tracked report, likely under `reports/control_plane/` or `reports/deferred/non_blocking/` depending on governance, to record:
   - current worktree states,
   - stash inventory,
   - external snapshot path,
   - what is safe to restore,
   - what must remain deferred.
3. Compare `stash@{0}` against `d2d16366`.
4. Decide whether each tracked WIP file should be restored, superseded, or archived.
5. Do not pop stashes; restore selected hunks/paths only after review.
6. Preserve lane1 and lane3 before any rebase.

Minimum commands to start:

```bash
git status --short --branch --ahead-behind
git stash list --date=local --pretty='%gd %cd %gs'
git stash show --name-status stash@{0}
git stash show --patch stash@{0} -- .claude/rules/wave-protocol.md CLAUDE.md STATUS.md TASKS.md mu/tools/executors/executor_config.json
git -C ../workingrcx_lane1_castage0c_20260616 status --short --branch --ahead-behind
git -C ../workingrcx_lane3_observability_20260619 status --short --branch --ahead-behind
```

### 5. STAGE0-CONTENT-ADDRESSED-TYPEDISPATCH-DECISION-RECOVERY-2026-06-20

Status: queued, blocked by contradiction.

Worktree:

```text
/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/workingrcx_lane1_castage0c_20260616
```

Blocker:

- The Stage0 branch's blocking report says Python needs input-side raw-list fail-close to preserve behavior/parity.
- Current P7W4 fence forbids analogous `list` token.

Goal:

- Resolve the contradiction before committing or rebasing staged implementation work.

Recommended approach:

1. Read the staged blocking report:
   `reports/deferred/blocking/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16_phase_a_contradiction.md`
2. Re-read affected tests:
   - `mu/tests/l4_gates/test_p7w4_structural_reduction_gate.py`
   - `mu/tests/l4_gates/test_stage0_content_addressed_collapse_gate.py`
   - `mu/tests/l4_gates/test_stage0_vm_cutover.py`
3. Classify whether the right fix is:
   - update the P7W4 fence because the raw-list fail-close is a boundary guard, not semantic dependency,
   - change the Stage0 implementation to avoid raw-list handling,
   - split the wave into decision packet plus implementation recovery.
4. Do not rebase/commit first. The branch is behind `origin/dev` by 80 after PR #1132.

### 6. PIPELINE-EASY-SWITCH-PROPAGATION-2026-06-20

Status: queued, not implemented.

Goal:

- Make orchestrator, implementer, reviewer, pager, autoping, and tmux switch state deterministic and durable across launcher, routing records, Phase B handoffs, commit executor, and dashboards.

Important distinction from user:

- Orchestrator is not the same as implementer/reviewer.
- Claude may be orchestrator while implementer/reviewer are different.
- Codex may be orchestrator while implementer/reviewer are different.
- Pager/autoping/tmux must follow the session orchestrator where appropriate, while implementer/reviewer model choices remain separate.

Code-grounded evidence for current gap:

- `reports/control_plane/active-queue-wip-preservation-sync-2026-06-20_wave_config.json:13-15` carried:
  - `implementer_agent: codex`
  - `reviewer_agent: codex`
  - `pager_route: codex`
- `mu/tools/executors/launch_wave.py:732-741` maps those config pins to dispatcher child env overrides.
- `mu/tools/executors/launch_wave.py:744-768` sanitizes and injects those env vars only for the child process.
- `mu/tools/executors/commit_executor.py:137-151` allowed handoff fields do not include `pager_route`, `implementer_agent`, or `reviewer_agent`.
- `mu/tools/executors/commit_executor.py:9899-9928` `build_commit_handoff(...)` also has no role/pager parameters.
- `mu/tools/observability/pipeline_agent_pager.py:632-638` resolves pager route as explicit route, env override, orchestrator mode, then `executor_config.json` route/default.

Careful wording:

- The proven defect is that role/pager pins do not persist through commit handoffs.
- The earlier accidental Claude process cause should be treated as a hypothesis unless tied to that specific run's command/log output.

Suggested design:

1. Add a single source of model/role truth, likely `models.json` or an extension of existing executor config, so model names such as `codex 5.5 xhigh` update in one place.
2. Add explicit fields for:
   - `orchestrator`
   - `implementer_agent`
   - `implementer_model_ref`
   - `reviewer_agent`
   - `reviewer_model_ref`
   - `pager_route`
   - `autoping_route`
   - `tmux_lane`
3. Teach `launch_wave.py` to persist those fields into routing records, not only child env.
4. Teach Phase B handoff and commit handoff builders to carry the fields.
5. Teach `commit_executor.py` to use the persisted fields and fail closed if direct fallback would use stale config defaults.
6. Teach tmux/dashboard scripts to render "who is working" from the same durable state.
7. Add tests for direct commit-executor fallback with no env override.

Possible files to inspect:

```text
mu/tools/executors/launch_wave.py
mu/tools/executors/executor_common.py
mu/tools/executors/executor_config.json
mu/tools/executors/phase_b_executor.py
mu/tools/executors/commit_executor.py
mu/tools/observability/pipeline_agent_pager.py
mu/tools/observability/pipeline_monitor.sh
mu/tools/observability/_pane_processes.sh
mu/tools/observability/_pane_timeline.sh
mu/tools/session/codex_autoping_watch.py
mu/tools/session/codex_autoping_window.sh
```

### 7-11. Narrow Pipeline Fixes

Status: queued after higher-priority structural/WIP/easy-switch work unless non-overlap allows parallel execution.

Items:

- `PIPELINE-FIX-33`
- `PIPELINE-FIX-29`
- `PIPELINE-FIX-31`
- `PIPELINE-FIX-17`
- `PIPELINE-FIX-34`

Known detail for `PIPELINE-FIX-34`:

- Recovery Tier 3 bot-finding durable-edit fix.
- Need `bot_findings_pending` recovery to require/apply structured edit actions instead of exhausting after meta-envelope-only output.
- Root evidence in tracker: `.agent_bus-active-queue-post-gcd/recovery/recovery_status.json` ended `tier3_exhausted`; tracker retained indicator-only evidence after three recovery attempts.

General constraints:

- Use builders/launcher/pipeline.
- Split waves by file ownership when parallelizing.
- Let pipeline own `TASKS.md` conflict handling.
- Do not bundle with StructuralNumbers runtime changes.

## Validation Already Run For Queue Sync

Before PR #1132:

```bash
./tools/checks/check_docs_consistency.sh
PYTHONHASHSEED=0 python3 -m pytest -q tests/docs/test_doc_freshness.py tests/docs/test_manifest_discoverability.py tests/docs/test_debt_truth_gate.py mu/tests/structural/test_status_md_grounding.py --tb=short
python3 tools/checks/enforce_l4_execution_contract.py --staged --wave-id active-queue-wip-preservation-sync-2026-06-20
git diff --check --cached
```

Commit executor / PR checks after push:

- `test`: success
- `green-gate`: success
- fixture gates: success

## Known Tooling/Pipeline Lessons From This Session

1. Commit handoff `task_id` must be bracketed live TASKS authority for Gate 8. The first handoff used the wave id as `task_id` and failed. Regenerating with `[NEXT-CODEX-POST-REDTEAM]` fixed the gate.
2. `launch_wave.py` branch policy expects canonical branch `jabramsja/<wave-id>` or restart descendants for normal wave landing. The initial noncanonical branch name was rejected by `commit_executor` validation; local branch was renamed to `jabramsja/active-queue-wip-preservation-sync-2026-06-20`.
3. Commit executor post-merge cleanup may stash tracked main-worktree WIP. This happened here and created `stash@{0}`.
4. External local preservation artifacts are not repo-canonical until tracked or referenced by a tracked report.
5. No live Claude processes were found during final checks. Keep Codex-only constraints explicit until the easy-switch propagation wave lands.

## Suggested Immediate Next Actions

Do these only after user approval to continue beyond this handoff:

1. Start with a fresh preflight/status check.
2. Decide whether to do WIP preservation before StructuralNumbers Stage 4. Canonical `TASKS.md` lists StructuralNumbers Stage 4 first, but operationally WIP preservation is safer before any dirty-lane sync/rebase.
3. If doing WIP preservation:
   - create a dedicated wave,
   - use launcher/builder,
   - create tracked preservation report,
   - inspect `stash@{0}`,
   - preserve lane1 and lane3 before mutation.
4. If doing StructuralNumbers Stage 4 design:
   - keep it design-only,
   - do not touch dirty WIP lanes,
   - avoid easy-switch or Stage0 scope.
5. If doing easy-switch:
   - implement durable config propagation, not manual env workarounds,
   - add direct-fallback regression tests,
   - document orchestrator vs implementer/reviewer distinction.

## Commands For Next Session Startup

```bash
cd /Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/WorkingRCX
git status --short --branch --ahead-behind
git log --oneline --decorate -n 8
git worktree list --porcelain
git stash list --date=local --pretty='%gd %cd %gs' | sed -n '1,20p'
nl -ba TASKS.md | sed -n '670,755p'
nl -ba STATUS.md | sed -n '160,168p'
```

Optional but recommended before WIP recovery:

```bash
git stash show --name-status stash@{0}
git stash show --patch stash@{0} -- .claude/rules/wave-protocol.md CLAUDE.md STATUS.md TASKS.md mu/tools/executors/executor_config.json
find /Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/.rcx_wip_preservation/20260620T171515Z -maxdepth 2 -type f | sort | sed -n '1,160p'
```

## Hard Stops

- Do not drop or pop stashes.
- Do not run destructive git commands.
- Do not rebase lane1 Stage0 work before resolving the contradiction report.
- Do not treat the external `.rcx_wip_preservation` directory as committed truth.
- Do not manually patch easy-switch behavior as a one-off; implement or queue the deterministic structural fix.
- Do not start the next wave unless the user asks to continue.
