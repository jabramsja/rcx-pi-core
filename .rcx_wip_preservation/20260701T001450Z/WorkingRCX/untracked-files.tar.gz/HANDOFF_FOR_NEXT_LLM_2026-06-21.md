# HANDOFF — 2026-06-21 (claude pager/autoping codex-parity + 3 in-flight waves)

DOC_STATUS: HANDOFF (point-in-time operational state; not a canonical state file). Author: claude orchestrator session `65c45d64`. Time: ~01:47 EDT 2026-06-21. dev tip: `0e3d358e`.

---

## 0. TL;DR

Three dispatcher waves are running detached, in parallel, non-conflicting files:
- **lane4 — Stage0** content-addressed symmetric-fence collapse (L4_STRUCTURAL) — Phase-B r3.
- **lane5 — FIX-34** tier-3 bot_findings_pending durable-edit (L4_ENABLER) — **committed, PR #1139 OPEN, all 6 CI checks GREEN, merging** (lane5 dispatcher drives the merge).
- **lane6 — PAGER codex-parity** (L4_ENABLER) — Phase-A r3. **This is the "make the claude pager work like codex's" wave.**

The CLAUDE **pager** is NOT broken in the timeout sense (it delivers — 33 fresh `claude -p` pages exit-0 today across lane4/5). The actual gap vs codex: codex delivers each event INTO a **persistent shared monitor**; claude throws each page at a **fresh ephemeral subprocess**. The lane6 wave fixes that (deliver into the persistent monitor the watcher keeps). The **watcher** was genuinely broken earlier (self-pausing) and is now fixed + working. **Open decision for you: do we keep the watcher or retire it** (Section 5).

---

## 1. The pager/autoping architecture — codex vs claude (READ THIS FIRST)

There are THREE separate mechanisms. Do not conflate them (I did, repeatedly — see Section 8).

### 1a. CODEX model (works perfectly — the reference)
- **codex autoping** (`tools/session/check_codex_startup_state.py::_start_codex_app_server`) starts a persistent `codex app-server --listen ws://127.0.0.1:8765` daemon (tmux `rcx-codex-app-server`, up since Jun 9; 2 procs live now) and keeps a **persistent codex monitor THREAD** registered/warm.
- **codex pager leg** (`mu/tools/observability/pipeline_agent_pager.py::_dispatch_codex`, ~:1523) delivers each pipeline event as a `turn/start` **INTO that same persistent thread** (it reads the autoping's thread via `_read_latest_autoping_thread_id`), through the app-server (async fast-ack; codex processes the turn async). On a stale thread it starts a new one (`thread/start`).
- **KEY: codex's autoping and pager are CONNECTED — they share ONE monitor thread.** The autoping maintains it; the pager delivers into it. That sharing IS the autoping's point.

### 1b. CLAUDE current state (what's on dev `0e3d358e`)
- **claude pager leg** (`pipeline_agent_pager.py::_dispatch_claude`, ~:1811) ENQUEUEs the event to `mu/tools/session/claude_pager_receiver.py`, whose `delivery_command` (~:277) is a **FRESH, resume-less `claude -p`** per page (docstring ~:1850: "The monitor-resume path is gone entirely... pages with a fresh, resume-less claude -p"). Delivery is async/serialized + `event_id`-deduped + `ensure_draining` lazy-start (w1/w2b, PRs #1136/#1138). It reads NEITHER the monitor NOR the orchestrator session-id file.
  - This delivers (verified: `delivered.jsonl` on lane4 = 11 exit-0 pages, lane5 = 22 exit-0 pages today). The paged claude replies "Ack complete. Standing by." — i.e. it ACKs (the `_event_prompt` tells it "do not run tools / do not launch ...").
  - The 2026-06-17 design (`reports/deferred/non_blocking/pager-claude-quickack-receiver-design-2026-06-17.md`) DECIDED fresh-`claude -p` ONLY, dropping monitor-resume because the SYNC `claude --resume` timed out under the ~10-20s ack budget.
- **claude autoping = the WATCHER** (`mu/tools/session/claude_autoping_watch.py`) — separate from the pager (Section 2). Keeps a dedicated claude monitor SESSION warm.

### 1c. The codex-parity FIX (lane6 wave, in flight)
Make the claude pager deliver each event **INTO the persistent warm monitor** (`claude --resume <claude_monitor_session_id>` — the same session the watcher keeps warm) via the EXISTING async receiver (no timeout — the w2b async drain removes the reason monitor-resume was dropped). Mirrors codex's "deliver turn into the shared persistent thread." Guards: fresh-`claude -p` fallback on monitor unset / equals-live-orchestrator / resume-failure (never resume the live orchestrator); `RCX_CLAUDE_MONITOR=1` in the delivery env so the resume cannot clobber `orchestrator_session_id`. Keeps the existing `_event_prompt`. **This CONNECTS the watcher to the pager (codex-parity): watcher maintains the monitor ⟷ pager delivers into it.**
- Config: `/tmp/pager-claude-codex-parity-resume-monitor-2026-06-21.json` (generator `/tmp/gen_pagerfix.py`).
- Wave id: `pager-claude-codex-parity-resume-monitor-2026-06-21`; lane6 bus `.agent_bus-lane6`; worktree `../workingrcx_pagerparity_20260621`.

---

## 2. THE WATCHER (claude autoping) — what it is, current state, and the decision you asked for

### What it is
`mu/tools/session/claude_autoping_watch.py` — a `while True` loop (`--interval 20`, `--initial-delay 30`, `--ping-timeout 120`) that every 20s resumes a dedicated claude MONITOR session (`claude_monitor_session_id`) with a **keepalive "heartbeat"** prompt (`_render_prompt` ~:250) that EXPLICITLY says *"This is an autoping heartbeat... it is NOT a request to act on the pipeline. Do not run shell commands... Do not launch executor_dispatch.py... Stay idle and ready; the pager will resume this same session with real work when a pipeline transition occurs."* Tools mechanically disabled on the keepalive. It pages a CLAUDE (the monitor), NEVER the founder. It NEVER resumes `orchestrator_session_id` (the live orchestrator); pauses if `monitor == orchestrator`.

### Current state (verified, working)
- Watcher PID 35824, **ppid 1 (detached/nohup'd)**, alive ~1h17m.
- Monitor session: `76e0ba7c-8cbd-4e3c-90e2-cc430e49f8fc` (a FRESH SMALL session — 740KB; the old monitor `6f1aa5c6` had bloated to 80MB and timed out every resume).
- Orchestrator (this live session): `65c45d64-...` — DISTINCT from the monitor (no collision).
- autoping status: `ping_dispatched` (NOT paused); summary "Monitor is warm and idle; nothing needed attention"; 0 timeouts. Verified by a live mtime-advance during a 45s window.

### What was broken + the fix (so you know its history)
Two real bugs (both fixed operationally this session; structural fixes still pending — Section 7):
1. **Self-collision (structural):** `claude_autoping_watch._resume_env()` returns `os.environ.copy()` with NO `RCX_CLAUDE_MONITOR=1`, so when the watcher resumed the monitor, the resumed session's `session-start.sh` (else-branch) wrote its id into `orchestrator_session_id` → `orchestrator == monitor` → the watcher self-paused on its first ping.
2. **Bloated monitor (operational):** the registered monitor was an 80MB `6f1aa5c6.jsonl` → `claude --resume` exceeded the 120s ping-timeout every cycle → keepalive failed + burned tokens.
**Fix applied (verified working):** killed all watchers; created a fresh small monitor via `RCX_CLAUDE_MONITOR=1 CLAUDE_PROJECT_DIR=$PROJ claude -p "init" --output-format json --disallowedTools Bash Edit Write` (its session-start wrote `claude_monitor_session_id`); set `orchestrator_session_id` to this live session (distinct); restarted ONE watcher WITH `RCX_CLAUDE_MONITOR=1` via `RCX_CLAUDE_MONITOR=1 bash mu/tools/session/ensure_claude_autoping.sh --session-id <mon> --force-restart`. Full procedure now in memory `reference_claude_pager_watcher.md`, preflight step 15b (auto-detect+repair), CLAUDE.md Key Files, learning.md 2026-06-21.

### THE DECISION YOU ASKED FOR: do we need the watcher?
- **Argument to KEEP it (codex-parity):** in codex the autoping IS the monitor the pager delivers into. If the lane6 pager delivers into `claude_monitor_session_id`, SOMETHING must own that monitor's lifecycle (create it, keep it registered + small). The watcher is that owner. Connected = codex-parity.
- **Argument it's REDUNDANT:** `claude --resume <id>` loads the conversation from the on-disk `.jsonl` — it does NOT need the keepalive-warmth (UNLIKE codex, whose app-server holds the thread in-memory; that's why codex's autoping is mandatory and claude's may not be). So the watcher's periodic keepalive resumes are technically unnecessary for the pager to resume the monitor. The watcher also does NOT currently CREATE the monitor (I did, via `claude -p`); it only keepalives an existing one.
- **The two coherent options (your call):**
  - **Option A — keep the watcher** as the monitor lifecycle owner (enhance it to CREATE/recreate the monitor if absent/bloated, like codex's autoping re-registers its thread). Pager delivers into the watcher's monitor. Keepalive cost: one small `claude --resume` turn every 20s.
  - **Option B — retire the watcher**; have the **pager self-create + own** the persistent monitor (create-if-absent → register `claude_monitor_session_id` with `RCX_CLAUDE_MONITOR=1` → resume thereafter). No keepalive, no watcher process. Simpler, since claude resume needs no warmth. (This is NOT current lane6 scope — lane6 delivers into the watcher's monitor, Option A.)
- My recommendation if you want a single answer: **Option A** (keep + enhance the watcher to own monitor creation) — it's the literal codex-parity and keeps pager≠autoping separation while connecting them through the shared monitor. But B is legitimately simpler. **Lane6 as-launched assumes Option A.**

---

## 3. The three in-flight waves (detailed)

All launched via `mu/tools/executors/launch_wave.py <config.json> --repo-root <WT> --bus-dir .agent_bus-laneN --launch` (the builder). All dispatchers running.

### lane4 — Stage0 (L4_STRUCTURAL)
- Wave: `stage0-content-addressed-symmetric-fence-2026-06-20`; worktree `../workingrcx_stage0sym_20260620`; bus `.agent_bus-lane4`; dispatcher PID 72986 (2h16m).
- State: **Phase-B r3** (r1 NO_GO 6 findings → r2 → r3). Slow because it is L4_STRUCTURAL (fence-relax + content-addressed collapse + JS parity + gate tests, throttle-prone). recovery-clean. Implementer rounds active (max_turns 0 = real progress, not stuck).
- This is the founder's flagged "super important" Stage0 reduction.

### lane5 — FIX-34 (L4_ENABLER) — NEARLY DONE
- Wave: `pipeline-fix-34-bot-remediation-durable-edit-2026-06-20`; worktree `../workingrcx_fix34_20260620`; bus `.agent_bus-lane5`; dispatcher PID 52162 (2h08m).
- State: Phase-B converged r4 GO → committed (Step 9/10 COMMIT_GO) → pushed → **PR #1139 OPEN**, all 6 CI checks SUCCESS (test, green-gate, orbit-dot/provenance/svg, engine-run-schema), mergeStateStatus BLOCKED (= required_conversation_resolution / final merge step; the lane5 dispatcher Step-15/16 drives it). Should merge on its own; if it strands, see the stranded-PR recovery in learning.md.
- What it fixes: tier-3 `bot_findings_pending` recovery now requires + applies durable edits (no meta-envelope-only silent exhaustion). Converged as a finite-edge-set (#30), not divergence.

### lane6 — PAGER codex-parity (L4_ENABLER) — the pager fix
- Wave: `pager-claude-codex-parity-resume-monitor-2026-06-21`; worktree `../workingrcx_pagerparity_20260621`; bus `.agent_bus-lane6`; dispatcher PID 5141 (~2m, just relaunched).
- State: **Phase-A r3** (design review). It was launched once, I wrongly killed+nearly-re-scoped it (see Section 8), then relaunched on the CORRECT connected config.
- Scope: Section 1c. Subtle async/session surface — WATCH the Phase-B rounds for divergence (#52 risk); re-scope NARROW if findings oscillate, do NOT flip the design.

---

## 4. Pipelines are detached (your "nohup" requirement)

- **Watcher** PID 35824 is ppid 1 (truly detached). Survives session end.
- **Dispatchers** (lane4 72986, lane5 52162, lane6 5141) are children of their `launch_wave.py --launch` processes (harness background tasks), which have persisted 2h+ across many turns. They drive each wave to commit→merge then exit (the harness notifies on completion).
- I did NOT kill any of them. To relaunch a dead dispatcher: re-run its `launch_wave.py` command (idempotent/convergent) from its worktree, e.g.
  `python3 <WT>/mu/tools/executors/launch_wave.py <config.json> --repo-root <WT> --bus-dir .agent_bus-laneN --launch` (run detached).
- Configs are at `/tmp/<wave_id>.json` (regenerate from `/tmp/gen_stage0.py` / `gen_fix34.py` / `gen_pagerfix.py` if /tmp is cleared).

---

## 5. The watcher decision — see Section 2 (END). It is the one thing I need YOU to decide.

---

## 6. Verify commands (copy-paste)

```bash
PROJ=/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/WorkingRCX
OBS="$PROJ/.agent_bus/observability"; MON=$(cat "$OBS/claude_monitor_session_id")
# watcher health (want: ping_dispatched, 1 watcher, distinct ids)
python3 -c "import json;print(json.load(open('$OBS/claude_autoping_${MON}.json')).get('status'))"
pgrep -f claude_autoping_watch | wc -l
echo "orch=$(cat $OBS/orchestrator_session_id) mon=$MON"
# dispatchers
for L in lane4 lane5 lane6; do echo "$L: $(pgrep -f "executor_dispatch.*$L"|wc -l)"; done
# FIX-34 merge
gh pr view 1139 --repo jabramsja/rcx-pi-core --json state,mergeStateStatus
# pager deliveries (proof the pager works today — fresh claude -p)
wc -l ../workingrcx_*/.agent_bus-lane*/observability/claude_pager_receiver/delivered.jsonl 2>/dev/null
```

---

## 7. Structural follow-ups still pending (not yet landed)
1. **Watcher `_resume_env()`** should set `RCX_CLAUDE_MONITOR=1` explicitly (so a resume never clobbers `orchestrator_session_id` even if the launch env is missing it). Currently worked around by launching the watcher WITH the env.
2. **Pager codex-parity** = the lane6 wave (in flight). Lands the "deliver into the persistent monitor" change.
3. **Watcher monitor-lifecycle ownership** (Option A enhancement): make the watcher CREATE/recreate the monitor if absent/bloated (today preflight 15b does the repair; mid-session bloat is not auto-handled).
4. The 8-min cron prompt still says "CLAUDE pager delivery is still broken (timeout)" — that is STALE (delivery works; the real gap was codex-parity). Update the cron prompt text.

---

## 8. Churn lessons — so the NEXT session does NOT repeat my mistakes
I burned a lot of the founder's time/money flip-flopping on the pager. Do not repeat:
1. **The pager is NOT timeout-broken.** w2b made delivery async; it delivers (33 exit-0 pages today). Check the LANE buses' `delivered.jsonl`, NOT the main `.agent_bus` (which has no claude events).
2. **Read the design doc + the codex leg BEFORE scoping a pager change.** `pager-claude-quickack-receiver-design-2026-06-17.md` (founder DECIDED fresh-`claude -p`) and `_dispatch_codex` (codex delivers into a shared persistent thread). I twice scoped a wave blind and nearly reverted an intentional design.
3. **The watcher and pager must be CONNECTED (codex-parity), not separate.** Codex's autoping IS the monitor the pager delivers into. Do not "self-manage the pager monitor with no watcher" UNLESS you explicitly choose Option B and retire the watcher — leaving the watcher disconnected makes it pointless (founder's exact objection).
4. **Do not keep killing/relaunching the lane6 wave.** The connected config (`claude --resume <claude_monitor_session_id>`) is correct. Watch Phase-B; re-scope narrow only on real divergence.
5. The reasoning-depth/hedge Stop hooks fire on `likely`/`restart`/`failure`-without-file:line — cite evidence or use "hypothesis:".

---

## 9. Next steps
1. Let the 3 waves drive to merge (harness notifies). FIX-34 (#1139) is closest.
2. When lane6 (codex-parity) lands: the claude pager will deliver into the persistent monitor → verify a real transition resumes `claude_monitor_session_id` (not a fresh `claude -p`); update `reference_claude_pager_watcher.md` (its "pager resumes the monitor" mechanism note was aspirational until lane6 lands) + memory.
3. Decide the watcher question (Section 2). If Option A: queue the watcher-owns-monitor-lifecycle enhancement. If Option B: queue retiring the watcher + the pager self-managing.
4. Remaining queue — see Section 10 (FULL queue, not just the 3 waves).

---

## 10. FULL ACTIVE QUEUE (canonical in `TASKS.md` NOW section ~:675-739; carried from `HANDOFF_FOR_NEXT_LLM_2026-06-20.md`)

This is EVERYTHING in the queue, with current status as of this session. The 3 in-flight waves (Sections 3) are a SUBSET / adjacent to these. Canonical order in `TASKS.md`:

1. **STRUCTURAL-NUMBERS-STAGE4-DESIGN-2026-06-19** — *NOT STARTED (canonical next sequential).* Design Stage 4 integer-first numeric boundary after Stage 3 exact rationals landed (predecessors: PR #1126 gcd Python `ac7ca8ec`, #1127 gcd JS `da8e00a5`, #1129 rationals `20f2bf49`). Design-only; bounded packet; do NOT jump to cutover; do NOT mix with WIP/easy-switch. Start: re-read `mu/docs/core/StructuralNumbers.v0.md` + Stage 3 rationals impl + growth-cap tests; create Phase-A design packet via launcher.
2. **STRUCTURAL-NUMBERS-STAGE4-INT-FIRST-CUTOVER-2026-06-19** — *blocked on Stage 4 design.* Implement the integer-first boundary; preserve Python/JS parity; no host-semantics ratchet increase; update focused StructuralNumbers gates.
3. **STRUCTURAL-NUMBERS-STAGE5-ORDINAL-TO-N-2026-06-19** — *blocked on Stage 4 cutover.* von-Neumann ordinal→binary `N` bridge; sequential; maintain structural-purity proof limits; no host numeric shortcuts as semantic destination.
4. **WIP-PRESERVATION-DIRTY-WORKTREE-RECOVERY-2026-06-20** — *NOT STARTED; founder-involved; important before mutating dirty lanes.* Turn the local preservation snapshot into a tracked, reviewable recovery plan; reconcile `stash@{0}` + lane1 staged + lane3 dirty + shared stashes WITHOUT losing work. See Section 11. Do NOT pop stashes. Compare `stash@{0}` vs `d2d16366`, restore selected hunks only in a dedicated wave.
5. **STAGE0-CONTENT-ADDRESSED-TYPEDISPATCH-DECISION-RECOVERY-2026-06-20** — *blocked by contradiction on lane1.* The OLD lane1 Stage0 branch (`workingrcx_lane1_castage0c_20260616`, behind 80) is blocked: its blocking report says Python needs input-side raw-list fail-close to preserve parity, but the P7W4 fence forbids the `list` token. **NOTE: my lane4 wave `stage0-content-addressed-symmetric-fence-2026-06-20` (Section 3) is a FRESH attempt at this Stage0 reduction (the "symmetric fence" approach to resolve that exact contradiction)** — it is RELATED to this queue item. Read `reports/deferred/blocking/n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16_phase_a_contradiction.md` + the P7W4/stage0 gates before touching lane1. Do NOT rebase/commit lane1 until resolved.
6. **PIPELINE-EASY-SWITCH-PROPAGATION-2026-06-20** — *NOT STARTED.* Make orchestrator/implementer/reviewer/pager/autoping/tmux switch state deterministic + durable across launcher, routing records, Phase-B handoffs, commit executor, dashboards. **Directly relevant to the pager work.** See Section 13 for the full code-grounded detail.
7. **PIPELINE-FIX-33** — *queued* (per prior handoff; note: launch_wave landed as #30/PR #1118 — verify whether FIX-33 is distinct/still open before working it).
8. **PIPELINE-FIX-29** — *queued.* (tier-3 recovery validation_spec/delegate scope broadening for l4_gates gate-authoring waves — per learning.md 2026-06-18.)
9. **PIPELINE-FIX-31** — *queued.* (detect TRANSIENT_RATE_LIMIT result envelope → back-off-retry instead of burning tier-3 — per learning.md 2026-06-19.)
10. **PIPELINE-FIX-17** — *queued.* (growth-cap auto-bump must fold into the wave commit, not a post-commit edit — per learning.md 2026-06-17.)
11. **PIPELINE-FIX-34** — *IN FLIGHT (lane5, PR #1139 OPEN/merging — Section 3).* tier-3 bot_findings_pending durable-edit.
12. Lower-priority deferred research/cosmetic work only after the active queue clears.

**PLUS this session (NOT in the canonical queue, founder-directed):**
- **PAGER codex-parity** (lane6, in flight — Sections 1c/3). The founder's "make the claude pager work like codex" demand.
- **Watcher repair** (DONE this session — Section 2). Operational fix; structural follow-ups in Section 7.

**Parallelization rule (`TASKS.md:739`):** StructuralNumbers waves are SEQUENTIAL; Stage0 recovery is sequential with Stage0/runtime surfaces; easy-switch / WIP-preservation / narrow pipeline fixes may run in PARALLEL only when implementation file ownership does not overlap and the pipeline owns `TASKS.md` conflict handling.

---

## 11. STASHES + WIP TO PROTECT (DO NOT POP — carried from prior handoff)

**Top stash `stash@{0}`** (`commit_executor:primary_ffsync_tracked_wip:...`, Jun 20 13:25) — **IMPORTANT, do not drop.** Tracked main-worktree WIP that was live before a commit-executor post-merge cleanup. Paths:
`.claude/rules/wave-protocol.md`, `CLAUDE.md`, `STATUS.md`, `TASKS.md`, `mu/tests/docs/test_docs_registry_agent_memory_exempt.py`, `mu/tools/docs/docs_registry.json`, `mu/tools/executors/executor_config.json`, `mu/tools/observability/_pane_processes.sh`, `mu/tools/observability/_pane_timeline.sh`, `reports/control_plane/structural-numbers-gcd-2026-06-19_2026-06-19.md`.

**Other stashes (do not pop):** gcd-packet-repair (Jun 20 01:54), queue-status-rootenv (Jun 20 01:35), 3× codex-preserve (May 29), n3-js-evidence (May 22), codex-startup-checker (May 17), phase-a-recovery-unblock-pager (Apr 22).

**External preservation snapshot (NOT repo-canonical):** `/Users/jeffabrams/Desktop/RCX_X/RCXStack/RCXStackminimal/.rcx_wip_preservation/20260620T171515Z` (+ `/git-stashes` bundle/patches; + `/workingrcx_lane3_observability_20260619` lane3 snapshot). Useful evidence; not committed truth until a WIP-preservation wave (#4) tracks it.

**Safe handling:** never `git stash pop`; inspect with `git stash show --name-status/--patch stash@{N}`; compare `stash@{0}` vs `d2d16366`; restore selected non-conflicting hunks ONLY in the dedicated WIP-preservation wave (#4), never opportunistically.

---

## 12. ALL WORKTREES (current)

| Worktree | Branch | State |
|---|---|---|
| `WorkingRCX` (main) | `jabramsja/workspace-2026-06-04` | HEAD `d2d16366`... now dev `0e3d358e`; 4 untracked deferred reports live; tracked WIP in `stash@{0}` |
| `workingrcx_lane1_castage0c_20260616` | `n3-stage0-content-addressed-mu-typedispatch-reduction-2026-06-16` | **BLOCKED** (contradiction, behind ~80); staged Stage0 impl. Do NOT rebase/commit until queue #5 resolved. |
| `workingrcx_lane2_recoverygate58` | `dev` | clean |
| `workingrcx_lane3_observability_20260619` | `jabramsja/pipeline-observability-live-root-2026-06-19` | ahead 1, behind ~37; `M reports/control_plane/pipeline-observability-live-root-...md`. Preserve before any sync/rebase. |
| `workingrcx_stage0sym_20260620` (lane4, NEW) | `jabramsja/stage0-content-addressed-symmetric-fence-2026-06-20` | **IN FLIGHT** Phase-B r3 (Stage0 fresh attempt) |
| `workingrcx_fix34_20260620` (lane5, NEW) | `jabramsja/pipeline-fix-34-bot-remediation-durable-edit-2026-06-20` | **IN FLIGHT** PR #1139 OPEN/merging |
| `workingrcx_pagerparity_20260621` (lane6, NEW) | `jabramsja/pager-claude-codex-parity-resume-monitor-2026-06-21` | **IN FLIGHT** Phase-A r3 |

---

## 13. easy-switch (#6) — full detail (carried; relevant to the pager/orchestrator separation)

Goal: orchestrator / implementer / reviewer / pager / autoping / tmux switch state deterministic + durable. **Orchestrator ≠ implementer/reviewer** (claude can be orchestrator while implementer/reviewer differ; pager/autoping/tmux follow the session orchestrator; model choices stay separate). Code-grounded gap (verify against current dev):
- `launch_wave.py:732-768` maps config role/pager pins → dispatcher child ENV only.
- `commit_executor.py:137-151` allowed handoff fields do NOT include `pager_route`/`implementer_agent`/`reviewer_agent`; `build_commit_handoff` (~:9899) has no role/pager params.
- `pipeline_agent_pager.py:632-638` resolves route: explicit > env > orchestrator_mode > `executor_config` default.
- Proven defect: role/pager pins do NOT persist through commit handoffs (the "accidental claude process" cause is a HYPOTHESIS unless tied to a specific run's logs).
Suggested: single source of model/role truth (`models.json` or executor_config extension) with `orchestrator`/`implementer_agent`/`implementer_model_ref`/`reviewer_agent`/`reviewer_model_ref`/`pager_route`/`autoping_route`/`tmux_lane`; persist into routing records + Phase-B + commit handoffs; commit_executor uses them + fails closed on stale fallback; tmux/dashboard render from the same state; add direct-fallback regression tests. **The TWO existing switches** (`set_orchestrator_mode.py` MODE + `set_roles.py` ROLES) are the partial implementation — easy-switch makes them durable per-lane (`orchestrator_mode` is currently bus-local; lane waves fall back to the executor_config route).

---

## 14. FULL ACCOUNT OF MY PAGER/WATCHER STUPIDITY THIS SESSION (so you don't repeat it — founder demanded this be here)

I wasted hours + founder money flip-flopping. The sequence:
1. Reported the claude pager "working" (founder caught it — the receipts were throwaway acks, not me being meaningfully paged).
2. Diagnosed "w2b broke the pager / it should resume the monitor" — **WRONG twice over:** (a) I checked `delivered.jsonl` in the MAIN `.agent_bus` (empty) instead of the LANE buses (33 exit-0 pages) → falsely concluded "not delivering"; (b) the fresh-`claude -p` is the **founder-DECIDED 2026-06-17 design**, not a bug.
3. **The watcher was the ONE thing actually broken** — but I'd IGNORED `learning.md:83-84` (2026-06-17), which was auto-loaded in my context the whole time and already documented the exact collision + fix. I rebuilt/rediscovered it the hard way. (Now made ACTIVE: preflight 15b + memory + CLAUDE.md.)
4. Staged a wave to make the pager "resume the monitor / be actionable" — would have **reverted the founder's intentional fresh-`claude -p` design**. Founder said "read the documentation, look at the code" → I read the design doc + `_dispatch_codex` and caught it; discarded the wave.
5. Studied codex (founder: "look at codex's pager"). Found codex delivers into a persistent SHARED monitor thread; claude uses fresh ephemeral subprocess. Scoped the codex-parity wave (lane6) correctly = deliver into the persistent monitor.
6. Founder: "does it use the watcher or another method?" → I over-read it as "don't use the watcher" + pivoted toward self-manage + KILLED lane6 → **WRONG.** Founder: "if not connected, what's the point of the watcher?" = CONNECT them (codex-parity: watcher owns the monitor, pager delivers into it). Relaunched lane6 on the correct connected config.

**LESSONS (do not repeat):** the pager works (lane buses, 33 pages); the watcher was the broken thing (fixed); the watcher and pager must be CONNECTED (codex-parity) unless you deliberately choose Option B (Section 2) and retire the watcher; read the design doc + codex leg BEFORE scoping; check the auto-loaded learning entries BEFORE rebuilding; stop killing/relaunching lane6 — the connected config is correct.

---

## 15. HARD STOPS (carried + this session)
- Do NOT drop or pop stashes (Section 11). Do NOT run destructive git commands.
- Do NOT rebase/commit lane1 Stage0 before resolving its contradiction (queue #5).
- Do NOT treat `.rcx_wip_preservation/` as committed truth.
- Do NOT manually patch easy-switch as a one-off; implement/queue the durable structural fix.
- Do NOT kill/relaunch the lane6 pager wave again; the connected config is correct — watch Phase-B, re-scope narrow only on real divergence.
- Do NOT flip the pager design between fresh-`claude -p` and monitor-resume; the codex-parity answer (deliver into the watcher's persistent monitor) is settled (Section 1c).
- Pipeline-only for commits/merges; worktree-only; nohup for pipeline; MCP SQLite for bridge.db.
- The 8-min cron prompt's "pager delivery broken (timeout)" is STALE — delivery works; update it.

---

## 16. UPDATE — continuation session ~02:00 EDT 2026-06-21 (preflight + nohup relaunch)

A new orchestrator session ran /preflight (clean: CC 2.1.183 63/63 patches intact, auto-update flags correct, ratchets/JS-parity PASS, dream fresh, cron recreated `93c3d970`, Codex models_cache persona drift re-patched changed=54→OK). Then reconciled the "3 waves alive" claim with reality.

**FINDING: all 3 dispatcher waves were DEAD.** They stopped in a ~4-min window (lane4 01:47, lane6 01:48, lane5 01:51) when the prior session (`65c45d64`) ended. ROOT (founder-confirmed: "last session was told to do nohup...obviously it didn't"): they were harness/launch_wave background-task children = session-tied; only the watcher (true nohup, ppid 1) survived. `ps` showed zero executor procs (only an orphaned `tail`); no lane had a `recovery_status.json` (= killed, not crashed). Full mechanism in learning.md 2026-06-21 PIPELINE (nohup → ppid-1 reparent → survives).

**WATCHER DECISION = KEEP (Option A, codex-parity)** — settled by the founder's "read the codex way of paging/autoping and do that for you. main session claude." The autoping watcher maintains a persistent claude monitor; the lane6 wave connects the pager to deliver into it (mirrors codex's shared-thread model). Watcher is healthy (PID 35824, ppid 1, ping_dispatched, monitor `76e0ba7c` ≠ orchestrator, jsonl 2.3MB). Do NOT retire it. Section 2's "Option B" is rejected.

**ACTIONS TAKEN (this session):**
- **lane4 (Stage0)** relaunched via TRUE nohup → launch_wave PID 33195 (ppid 1), dispatcher+phase_a running, Phase-A round 2/15. Reset to Phase A (routing=ROUTE_PHASE_A; convergent re-run).
- **lane6 (PAGER codex-parity)** relaunched via TRUE nohup → launch_wave PID 37720 (ppid 1), Phase-A r1, implementer fixing 2 blocking findings. Pager observed delivering (fresh `claude -p`) live.
- **lane5 (FIX-34, PR #1139): NOT merged, left OPEN.** It is committed + CI fully green + MERGEABLE, BLOCKED only on conversation-resolution. The one unresolved thread is a **REAL P2** (not deferrable): FIX-34's `bot_findings_pending` branch hard-fails on any non-`edit` action, but `_build_diagnosis_prompt` (recovery_gate.py:5353-5356) still advertises `"shell"` as a valid fix action → a compliant agent returning a shell fix gets terminally hard-failed with no retry. Fix = make that prompt class-specific/edit-only for bot_findings_pending OR reprompt before hard-fail. Per the hard rule (don't merge over a true finding), it needs a remediation round. **Do NOT merge #1139 as-is; do NOT launch_wave-relaunch lane5 (committed → routing reset re-routes it backward).** Queue: re-dispatch FIX-34 fresh off dev with the edit-only-prompt fix in the request (close #1139 when the redo lands), or resume Step-15 round 2 via a stranded-PR path.

**STALE FACTS CORRECTED:** implementer is now **claude** (PR #1133 "switch implementer to Claude Opus 4"), reviewer=codex (live executor_config role_agents). FIX-33 already LANDED (#1134 bridge-config-autoseed MERGED) — queue item #7 is DONE. The new 8-min cron prompt has no "pager broken" stale text.

**NOHUP RULE for any relaunch:** `nohup bash -c 'cd <WT> && exec python3 mu/tools/executors/launch_wave.py <cfg> --repo-root <WT> --bus-dir .agent_bus-laneN --launch' > <WT>/.scratch/relaunch.log 2>&1 & echo PID=$!` in a PLAIN Bash call (never run_in_background); verify ppid=1 after.
