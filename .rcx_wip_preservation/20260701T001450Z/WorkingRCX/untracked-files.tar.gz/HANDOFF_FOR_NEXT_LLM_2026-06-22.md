# HANDOFF — RCX, 2026-06-22

**dev tip:** `73483308` (origin/dev). Main repo on a feature branch; do NOT rest on dev.
**Roles:** implementer = codex (gpt-5.5 xhigh), reviewer = codex (gpt-5.5 xhigh). Switch roles via `set_roles.py`; switch pager/autoping/tmux orchestrator ownership via `set_orchestrator_mode.py`.
**Constraint at handoff time:** the account hit the **seven-day claude rate limit** earlier in lane24 (`rateLimitType:"seven_day"`). Claude implementer waves will be throttled/blocked until the weekly window resets, so the active implementer was switched back to Codex. Do not switch implementer back to Claude unless the limit window has reset.

---

## 1. WHERE WE ARE

### Landed this session (all on dev `73483308`)
- **StructuralNumbers cross-substrate JS-parity COMPLETE** — rationals JS-parity (#1147) + the earlier ADD/compare/multiply/subtract parity all hold byte-identical (Python `run_mu` ↔ JS `bootstrap_core`).
- **Stage 0-c** + **4 pipeline structural fixes** (#1141 growth-cap routing-record, #1142 transient-limit recovery, #1143 control-packet line-ref normalizer, #1146).
- The StructuralNumbers arithmetic-as-projections program (ADD/compare/multiply/subtract + signed codec) is done and JS-parity-verified.

### Stage 4 (int-first matcher cutover) — THE current frontier, DECISION MADE
- **The goal:** make the matcher (`_stage0_match` / `stage0Match`) int-first — no host int/float reaches a matcher `{"var":...}` site at runtime. The blocker (`reference_stage4_var_site_failclose_blocker`): host-int engine counters (`max_steps`, `tau_step`) reach the matcher var sites at runtime.
- **What was built but PARKED:** a *boundary codec* shim (lane24, branch `jabramsja/stage4-boundary-mt200-2026-06-22`) that encodes counters→numerals at the matcher boundary and decodes them back to host ints for the engine loop. It **passed the full Phase-B dialectic (bridge GO r5 + private-attr r7 GO) + supervisor COMMIT_GO**, but is **PARKED, NOT landed** — see the decision below.
- **FOUNDER DECISION (2026-06-22): full structuralization, NOT the codec shim.** Rationale: the codec is the *wrong direction* — it ADDS host authority (+16 sites) to hide the host-arithmetic loop from the matcher, rather than removing it. The North Star is to MINIMIZE the host surface. The correct path is to **structuralize the engine loop's arithmetic** (the counting), which removes the host counters the matcher dispatches on.
- **Why the codec existed at all:** the full engine-loop structuralization **max-turned 3× at the 100-turn implementer ceiling**, so I detoured to the boundary codec. That was a *turn-budget* problem, not a difficulty wall — **now SOLVED** by the validated per-wave **max-turns-200** fix (see §3). So the full structuralization is now tractable.

### Pipeline state
- **Nothing running** (lane24 parked; no dispatcher/commit_executor alive). Codex autoping is live for thread `019eefa4-a8b5-7ac1-9a49-c2209189e04d`; main `pipeline_monitor` owner-loop is alive.
- Pager/autoping/tmux orchestrator mode is **codex** for `.agent_bus` / `rcx-pipeline`. Verified with `set_orchestrator_mode.py --mode codex ... --verify` and `tools/session/check_codex_startup_state.py`.
- tmux labels are restored: main window has PANE 1 live log / PANE 2 review findings / PANE 3 plain-English status / PANE 4 timeline; window 2 is `AUTO-PING`.
- lane24's codec worktree was removed; the branch is preserved for reference only.
- Founder execution constraint for next work: follow `FOUNDER_SESSION_BOOTSTRAP.md`; waves go through the pipeline only, never manual launches. Use parallel pipeline lanes when safe. Structural conversion must be in Mu/projections with no new host-authority sites. If a pipeline failure needs a manual unblock, the same wave must also run or queue the permanent root structural fix in builder, dispatcher, recovery, commit, or pre-commit tooling.

---

## 2. WHAT WE NEED TO ACCOMPLISH (priority queue, ~10 waves)

Full list also in TASKS.md (NEXT/queue). Priority order:

1. **Stage 4 — engine-loop-arithmetic structuralization** (the chosen full-structural path). Structuralize the engine loop's host arithmetic (`max_steps`/`tau` counting → compare/add projections on the landed StructuralNumbers) so no host int counter reaches the matcher var sites. **Keep the accepted `for`-loop iteration primitive** (Forth's-NEXT; minimize-not-eliminate). Current implementer is Codex; if roles are switched back to Claude, apply the validated max-turns-200 lane override. Anticipate the consistency surfaces (§3) in scope_items. Reopens the 2026-06-11 max_steps ACCEPTED-IRREDUCIBLE decision (the budget *value* being a host count vs the *counting* being host arithmetic are separable — structuralize the counting).
2. **Stage 4 — int-first matcher cutover (Wave B).** After #1, make `_stage0_match`/`stage0Match` int-first (no host-type dispatch at var sites). Now safe because #1 removes the host-int counters that reach the matcher (unblocks `reference_stage4_var_site_failclose_blocker`).
3. **Stage 4 — RED-TEAM** the structuralization + cutover (founder-requested). Adversarial review (verifier/adversary/structural-proof agents), L3 parity, no-host-leak.
4. **Surreals** as structure.
5. **Recursive ordinals** as structure.
6. **W-types / inductive types** (AST-as-inductive-structure — a self-hosting building block).
7. **Coinduction** (non-termination as structure).
8. **Fixpoint** — meta-circular evaluator-as-structure (the meta-circularity payoff).
9. **Pager / autoping codex-parity hardening** — route was restored to Codex at this handoff; keep a diagnosis-first wave queued for stale pager residue or parity gaps (do NOT rebuild blindly — see `reference_claude_pager_watcher`).
10. **Optimization** — LAST (founder-emphasized: needed after all the structural migration, not before).

**DROPPED (decided, do not pursue):** large cardinals; transfinite cardinals / higher-order sets (RCX is type-theoretic/rewriting, not set-theoretic).

**PARKED (needs splitting before retry):** the bridge-lock bounded-wait pipeline fix (2 attempts failed — caller-budget bot finding, then max-turns).

**Pipeline-hardening candidates (smaller, opportunistic):**
- recovery_gate.classify_failure should treat an `assert set(...)` engine-discipline assertion as `test_failure` (fixable), not `unknown_error` (short-circuit) — it stranded lane24's commit.
- Add a per-wave `max_turns` override field to `WaveConfig`/`launch_wave` (so a wave declares `max_turns=200` without the per-launch bridge_config edit or a blunt global default change).

---

## 3. WHY (the North Star) + KEY GOTCHAS for the next session

### Why
RCX is a **structural VM pursuing self-hosting + meta-circularity**. The evaluator logic (matcher, substituter, kernel projection-selection) should be RCX structure (Mu projections), running on a **minimal** host bootstrap primitive. The canonical position (`mu/docs/core/BootstrapStructuralBridge.v0.md:589-593`, 9-agent consensus): **"Some primitive must exist — the goal is minimizing it, not eliminating it"** (analogous to Forth's NEXT / Lisp's EVAL; L4 goal = minimize the bootstrap to ~6 lines). So: keep the `for`-loop iteration primitive, but structuralize everything around it (the arithmetic/counting). The codec shim violated this (added host); the structuralization serves it (removes host).

### Gotchas / validated recipes (critical for the Stage 4 wave)
- **max-turns-200 (VALIDATED, Claude-only fallback):** the engine wave needs >100 implementer turns under Claude (3× max-turned at 100; ~90 turns go to *exploration* of engine_pipeline.py). Current implementer is Codex, whose `bridge_config.json` command does not use `--max-turns`. If roles are switched back to Claude, after `launch_wave`, edit the lane's `bridge_config.json` claude agent cmd `"--max-turns","100"`→`"200"`. SAFE because `ensure_bridge_config_path` (executor_common.py) is create-if-missing (won't overwrite), `invoke_implementer` (phase_b_implementer.py:397) loads the lane config fresh, and `sync_bridge_config_agents_from_defaults` is called ONLY by launch_wave/set_roles (0 calls in phase_a/phase_b/dispatch). lane24 converged with this.
- **Anticipate consistency surfaces** (these stranded lane24's commit — put them in scope_items so the implementer updates them in-wave): (1) `STATUS.md` debt counts (Authority sites / Total inventory sites; Python+JS); (2) `mu/tests/structural/test_engine_pipeline_discipline.py:1176` `_EXPECTED_ENGINE_REQUIRES` (must list any new engine file); (3) `mu/tools/checks/host_authority_inventory_baseline.json` (`--update-baseline` for new sites). A full-structuralization wave that REMOVES host arithmetic should *decrease* these (good) — but it still must keep STATUS.md and the baseline in sync or `tests/docs/test_debt_truth_gate.py` fails at the commit gate.
- **launch_wave recipe:** `reference_wave_launcher` memory. Keep wave_id short (`len(wave_id)+11 < 70`, else "Unsafe plan_name"). `primary_blocker_class` ∈ {DESIGN,INTEGRATION,PERFORMANCE}. L4_STRUCTURAL takes `structural_artifact_ref`+`post_gate_contract_sweep`; `workload_target`/`host_semantics_delta` go in the tracker note (implementer self-recovers). Config must be line-ref-clean + title asterisk-free.
- **nohup launch:** `nohup bash -c 'cd WT && exec python3 .../launch_wave.py <cfg> --repo-root WT --bus-dir .agent_bus-laneN --launch' & ` then verify ppid=1. NEVER harness `run_in_background` (session-tied).
- **Switches:** `python3 mu/tools/executors/set_roles.py --implementer codex --reviewer codex` controls implementer/reviewer roles. `python3 mu/tools/session/set_orchestrator_mode.py --mode codex --repo-root "$PWD" --bus-dir .agent_bus --tmux-session rcx-pipeline --apply` controls pager/autoping/tmux ownership. Keep these separate.
- **Full diagnosis detail:** `.claude/rules/learning.md` (the 2026-06-22 entries: the max-turns-200 fix, the consistency-miss commit-strand, the recovery-classifier gap) + memory `project_next_wave_context`, `reference_stage4_counter_numeral_boundary`, `reference_stage4_var_site_failclose_blocker`.

---

## 4. IMMEDIATE NEXT STEP

Next session can scope + launch the **Stage 4 engine-loop-arithmetic structuralization** wave (queue item #1) with Codex as implementer — full-structural, counting-not-iteration, anticipate the consistency surfaces. If someone switches back to Claude first, apply the max-turns-200 lane override. Then Wave B (matcher cutover), then the red-team. Do NOT land the codec shim (lane24).
