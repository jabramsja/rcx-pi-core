# HANDOFF — Nightly regression root-cause + structural cutover-to-mu fix plan (2026-06-29)

**Context:** Founder hit ~7% max-usage limit mid-session. Directive: do full diagnosis, make the
BEST MOST STRUCTURAL root fix plan (regardless of blast radius), make narrow waves, queue them in
TASKS.md + todo, then provide this handoff. **Crons + pager/autoping were turned OFF** per founder
(usage). **Do NOT launch waves yet — this session only plans + queues.** Roles = claude/claude (live).
dev tip `51130976`. Working repo 82 behind dev (parked — founder-gated WIP).

---

## 1. THE FINDING (verified, decisive — NOT flakiness)

The nightly `slow_tests.yml` has been RED since 2026-06-26. It is a **REAL DETERMINISTIC PRODUCTION
REGRESSION** introduced by the Stage-4 matcher cutover, **not** parallel-load flakiness. My earlier
2026-06-29 triage that called it "full-nightly-scale flakiness" was WRONG — I only serial-tested the
*parity* suite and never ran the actual dominant failures. The founder caught this ("there is a reason").

### Evidence chain (every step run, not conjectured)
1. **Latest nightly:** run `28390575937` (2026-06-29T17:27, headSha `51130976`) — failure. RED 06-26/27/28/29; last green 06-25 (`28187056273`).
2. **Dominant failure (48 of ~95):** `tests/engine/test_hemisphere_adversarial.py::TestHemisphereStructuralInvariants` → `AssertionError: Missing hemisphere key: r_null`. Other families: `test_recurrence_production` (tau), `test_boot1_shadow_parity`, `test_js_parity_automated`, `test_rcx_engine_workload_contract`.
3. **DETERMINISTIC (ran serially, no xdist):**
   - `test_result_has_five_hemisphere_keys` → **8 failed, 6 passed in 82.43s** serially.
   - `test_recurrence_production::test_closure_detection_scaling` → **5 failed in 48.00s** serially.
   - Both fail serially ⇒ deterministic, not a race.
4. **The assertion reveals the shape:** result is `{'route_hemisphere': {'engine_result': {...}, 'hemispheres': {r_null:None, r_inf:None, r_a:None, lobes:None, sink:...}}}` — i.e. the routing **did not reduce**; it echoed back the unreduced input. The test (`test_hemisphere_adversarial.py:101`) asserts the 5 keys at the **top level** of `_route()`'s result.
5. **PRODUCTION is broken (not just the test helper):** ran the production entry directly —
   - `run_hemisphere_routing(<engine_result with host-int tau_step=10/value=99>)` → **`RcxEngineError: "Hemisphere routing did not produce valid hemisphere dict. Got: ['route_hemisphere']"`**.
   - Same entry with a **null** engine_result → **OK → `r_null`**.
   - Repro script: `/tmp/hemi_prod.py` (in this session's tmp; re-create from §5 below).
6. **Not a step-budget issue:** stalls at `max_steps` 20, 50, AND 200 (repro `/tmp/hemi_repro.py`) ⇒ permanent **host-int fail-close**, not insufficient steps.

### Root cause
- **`git log --since=2026-06-25 --until=2026-06-27 -- <routing+selfhost>`** → the ONLY change is
  **`f3332f18` "Phase B implementation for stage4-loop-struct-2026-06-22"** = the **Stage-4 int-first matcher cutover**.
- The int-first matcher **fail-closes on host-ints at `_stage0_match` var sites** (by design — the cutover's whole point: numerals are structural, host-ints are rejected).
- `run_hemisphere_routing` (`mu/host/python/rcx_pi/selfhost/engine_pipeline.py:1567`) wraps the
  engine_result and calls `run_mu_structural(projs, wrapped, max_steps=30, validation_mode="algorithm_runtime")`
  **WITHOUT codec'ing the engine_result's host-int fields** (`tau_step`, `value`). Those host-ints reach
  the matcher → fail-close → routing stalls → returns the unreduced `{route_hemisphere:{...}}`.
- The hemisphere keys are seed-derived + **fail-closed** (`step_mu.py:256` `_load_hemisphere_keys` raises if the seed yields != the 5 keys), so the missing key is NOT a key-set bug — it is the routing RESULT never being produced.
- **Predicted** by memory `reference_stage4_var_site_failclose_blocker`: "host-arith `max_steps`/`tau_step` reach `_stage0_match` at `{var}` sites; proven 9/36 engine fails." The cutover added the §7 host-boundary codec for `max_steps` (`engine_pipeline.py:164-210`, requires `max_steps` as a `{_num}` numeral) but **DEFERRED** the codec for the engine_result fields at the routing boundary. That deferral is the regression.
- **Why the fast green-gate missed it:** these tests are `@pytest.mark.slow` / `l4_expensive` → nightly-only. The fast green-gate (`-m "not slow"`) never runs them, so the cutover merged green while breaking the nightly.

### Blast radius (same root — host-int reaches the post-cutover matcher)
- `test_hemisphere_adversarial` (198 log hits) + `test_hemisphere_routing` (84) — hemisphere routing, host-int `tau_step`/`value`.
- `test_recurrence_production` (confirmed serial) + `test_recurrence_parity` — recurrence host-int `tau`.
- `test_boot1_shadow_parity`, `test_js_parity_automated` — JS mirror (the cutover deferred the JS mirror per `reference_stage4_counter_numeral_boundary`).
- `test_rcx_engine_workload_contract::test_host_tau_step_zero_fails_closed_on_python_and_js` — NOTE: this one EXPECTS host_tau_step to fail closed, so it may be a contract-intent test that needs reconciling, not a pure regression. **VERIFY its intent in next session.**

---

## 2. THE STRUCTURAL ROOT FIX (founder: best/most-structural, cutover to mu, any blast radius)

Founder's words: *"we want everything to be in mu, so we need cutover to mu!"* The host-int engine
counters (`tau_step`, `value`, `max_steps`) are the **last host-arith leak** reaching the matcher.

**Two directions — the founder chose the structural one (cutover to mu), boundary-codec is the band-aid:**

- **(A) STRUCTURAL ROOT FIX = full engine-counter cutover to mu (CHOSEN).** Make the engine's internal
  counters (`tau_step`, and any host-int engine_result field that reaches routing/matching) **StructuralNumbers
  numerals THROUGHOUT** the engine loop, so the hemisphere/recurrence routing operates on numerals (which the
  post-cutover matcher accepts). Host-ints appear ONLY at the final **host-facing response boundary** (decoded
  for the API/run_trace contract) — never before routing/matching. This completes the deferred "full engine
  host-arith structuralization" (`reference_stage4_var_site_failclose_blocker`: "beyond slice-1"). This is the
  real cutover-to-mu, no boundary band-aid.
  - Key insight from `reference_stage4_numeral_runtime_gotchas`: the engine already encodes at the `run_algorithm`
    boundary (Flow-B copy) and decodes terminal `tau_step` in `_classify_engine_step` for the OUTPUT contract.
    The GAP: hemisphere/recurrence routing runs on the DECODED (host-int) engine_result. The fix: route on the
    NUMERAL form (route before decode, or carry numerals into routing), decode only at the final response.

- **(B) Boundary-codec band-aid (NOT chosen, documented for completeness / fast-restore option).** Encode the
  engine_result host-int fields via the existing §7 codec before `run_mu_structural` in `run_hemisphere_routing`
  (+ recurrence) and decode at read. Restores green faster but re-introduces a host-int decode boundary —
  contrary to "everything in mu."

---

## 3. THE PLAN — narrow waves (queue; do NOT launch this session)

Each wave is `L4_STRUCTURAL` (touches runtime + `tests/l4_gates/` + `host_semantics_delta` + `evidence_command`),
self-host-forward, NEVER adds host semantics. Reviewer/implementer = claude (live). Sequence them (later waves
depend on the engine-numeral flow landing first). Land like supervisor-machinery waves if self-referential.

- **Wave NR-1 — hemisphere routing on numeral engine_result (Python).** Carry `tau_step` (+ any host-int field)
  as a numeral into `run_hemisphere_routing`; route on the numeral form; decode only at the host-facing response.
  Evidence: `test_hemisphere_adversarial.py` + `test_hemisphere_routing.py` pass SERIALLY (`-m slow`), and
  `run_hemisphere_routing(<host-int er>)` no longer raises (it now receives/uses numerals).
- **Wave NR-2 — recurrence `tau` on numerals (Python).** Same for the recurrence path (`test_recurrence_production`,
  `test_recurrence_parity`). Evidence: those pass serially.
- **Wave NR-3 — JS mirror.** Mirror NR-1/NR-2 to `mu/host/js` (the cutover deferred the JS mirror). Evidence:
  `test_js_parity_automated`, `test_boot1_shadow_parity` pass; `node mu/host/js/eval_step.js` healthy; cross-substrate parity byte-identical.
- **Wave NR-4 — boot1 + remaining.** `test_boot1_shadow_parity` (Python side) + any residual `l4_expensive` failure;
  reconcile `test_rcx_engine_workload_contract::test_host_tau_step_zero_fails_closed_*` (verify whether its
  fail-closed expectation is correct post-cutover or needs updating).
- **Wave NR-5 — full nightly green verify.** Re-run the FULL `-m l4_expensive` suite under the nightly's xdist
  count; confirm green; if any residual, repeat the §4 protocol on it. (Also re-check the original
  parity-suite "flakiness" claim — it may have been masking a real failure too.)

**Scope/urgency (founder asked me to choose):** HIGH urgency (dev's nightly is red = the engine is broken for
real host-int workloads; only the slow lane catches it). Do NR-1 first (biggest blast = hemisphere, 48/95),
then NR-2, NR-3 (JS), NR-4, NR-5. NR-1+NR-2 are Python-only and independently landable; NR-3 depends on them.

---

## 4. METICULOUS DIAGNOSIS PROTOCOL FOR NEXT SESSION (run under full usage to finish the diagnosis)

I confirmed hemisphere + recurrence. Boot1/parity/workload still need the same treatment. Per failing family:

1. **Get the live failure set:** `gh -R jabramsja/rcx-pi-core run list --workflow slow_tests.yml --limit 4`;
   `gh run view <latest-failure-id> --log-failed | grep -aoE 'FAILED [^ ]+|AssertionError[^"]{0,60}' | sort | uniq -c | sort -rn`.
2. **Make a dev worktree:** `git worktree add --detach <wt> origin/dev` (this session used
   `workingrcx_nightlydiag_20260629` at `51130976` — reuse or recreate).
3. **Serial-reproduce (deterministic vs race):** `cd <wt> && PYTHONHASHSEED=0 python3 -m pytest <test::Class::method> -p no:cacheprovider --no-header -q`. Use the Bash-tool `timeout` param (macOS has NO `timeout` binary — do NOT shell-wrap it). Fails serially ⇒ deterministic regression.
4. **Trace the host-int to the matcher:** read the production entry (e.g. `run_hemisphere_routing` @ engine_pipeline.py:1567); confirm it passes a host-int field into `run_mu`/`run_mu_structural` without codec; then run the production entry DIRECTLY with a host-int input and confirm `RcxEngineError`/stall. Repro pattern (recreate):
   ```python
   import sys; sys.path.insert(0,"mu/host/python"); sys.path.insert(0,".")
   from rcx_pi.selfhost.engine_pipeline import run_hemisphere_routing
   from tests.hemisphere_helpers import make_engine_result, empty_hemispheres
   er = make_engine_result(value=99, tau_step=10, exhaustion_detected=True, operator_frozen="op", frozen_set=[], action="halt", stall=True)
   try: print("OK", run_hemisphere_routing(er, empty_hemispheres()))
   except Exception as e: print("FAILS", type(e).__name__, str(e)[:120])
   ```
5. **Build the (boundary, host-int-field) list** that fail-closes → that IS the scope of the structuralization waves (§3).
6. **Verify each fix:** after each wave, run the family serially + then the full `-m l4_expensive` suite.

Key facts: hemisphere keys are seed-derived + fail-closed (`step_mu.py:256`); the §7 max_steps codec is at
`engine_pipeline.py:164-210` (the PATTERN the cutover used — mirror its intent but the founder wants the
full numeral flow, not a per-boundary codec). Memories: `reference_stage4_var_site_failclose_blocker`,
`reference_stage4_counter_numeral_boundary`, `reference_stage4_numeral_runtime_gotchas`.

---

## 5. SESSION STATE / ARTIFACTS
- **Crons OFF** (deleted 45f8ca9a 8-min + ba1e8184 hourly). **Pager/autoping OFF** (0 watchers). Re-enable next session via preflight steps 15/15b if desired.
- dev `51130976`; roles claude/claude; main repo 82-behind dev (parked, founder-gated WIP — do not clobber).
- Diag worktree `workingrcx_nightlydiag_20260629` @ `51130976`; repros `/tmp/hemi_repro.py`, `/tmp/hemi_prod.py`.
- Earlier this session LANDED (all via healthy pipeline): #19 strand-fix (PR #1177), coind3 (#1178), #4 autoping (#1179), #17 bot-remediation (#1180). Scoped (deferred notes): #15 wave_evidence, #8 bridge-lock. Memory consolidated, `.last_dream`=2026-06-29.
- **Do NOT launch waves** — founder said plan + queue only this session.

---

## 6. FULL TASK STATE (all 25 session todos — mirrored into TASKS.md "FULL TODO-LIST RECONCILIATION")

- **🔴 URGENT nightly (this handoff):** #21 NR-1 hemisphere-numeral (DO FIRST, 48/95) · #22 NR-2 recurrence-numeral · #23 NR-3 JS mirror · #24 NR-4 boot1+remaining+reconcile-`workload_contract` · #25 NR-5 full-nightly green-verify · #10 umbrella (DIAGNOSED).
- **Program-structural queue (TASKS.md items 3-9):** #11 host-semantic reduction + #12 structural-type families → Surreals/Ordinals/W-types **LANDED** → **Coinduction** (NEXT; foundation landed, design `mu/docs/core/Coinduction.v0.md`) → **Fixpoint** → #9/#20 **Optimization** (LAST; #20 = fallback reads `executor_config.json` once not twice).
- **Pending pipeline/infra/founder-gated:** #2 never-behind-dev (*in_progress*; main repo **82-behind + dirty** → founder-gated, NEVER clobber) · #3 control-plane Wave 2 (*in_progress*; recipe `reports/deferred/non_blocking/claude-control-plane-cleanup-test-updates-2026-06-27.md`) · #6 commit WorkingRCX WIP (founder-gated, per-file judgment) · #8 bridge-lock bounded-wait (PARKED; `bridge-lock-bounded-wait-8-scoping-2026-06-29.md`) · #15 wave_evidence self-reference (scoped; `wave-evidence-self-reference-15-scoping-2026-06-29.md`; grep-evidence interim).
- **Completed this session (landed dev `51130976`):** #1 claude-roles · #4 autoping (PR #1179) · #5 rcx_session_protocol · #7 control-plane follow-ups · #13 recovery-gate strand (PR #1170) · #14 DEFAULT-backends-derive (PR #1171) · #16 agent-menu fallback · #17 bot-remediation autodefer (PR #1180) · #18 L4-indicator pre-stage · #19 disposition-deferrable strand (PR #1177).
- **Deferred notes filed (`reports/deferred/non_blocking/`):** `nightly-slow-tests-red-...-2026-06-29.md` (**SUPERSEDED by this handoff** — it wrongly called the nightly "flakiness"), `wave-evidence-self-reference-15-scoping-2026-06-29.md`, `bridge-lock-bounded-wait-8-scoping-2026-06-29.md`.
- **OFF (founder-requested, usage):** both session crons deleted (`45f8ca9a`, `ba1e8184`); pager/autoping watcher killed (respawned once, no crontab/launchd respawner found — re-check next session via preflight 15b).
