#!/usr/bin/env bash
# RCX SESSION PROTOCOL — shared by whichever LLM is the orchestrator (Claude OR Codex).
# Run by: preflight Step 0.5 (Claude), the hourly protocol cron, and Codex startup.
# READ-ONLY: it points to the canonical surfaces, enumerates the standing imperatives, and
# verifies live state. It does NOT apply config (preflight Step 0 owns the apply) and does NOT
# duplicate or edit FOUNDER_SESSION_BOOTSTRAP.md.
#
# POLYMORPHIC ROLES: the LLM assigned to EACH pipeline role is runtime-configurable by the founder,
# in ANY combination, and changes at will. NEVER hardcode or assume which provider plays any role —
# always verify live (set_roles --show / orchestrator_mode.json).
set -uo pipefail
ROOT="${CLAUDE_PROJECT_DIR:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}"
cd "$ROOT" 2>/dev/null || true
echo "================= RCX SESSION PROTOCOL ================="
echo "when: $(date)"
echo "orchestrator (active session label): ${RCX_ORCHESTRATOR:-unset — set RCX_ORCHESTRATOR=claude|codex to label}"
echo
echo "--- REQUIRED READS (read in full before substantive work) ---"
echo "  Codex bootstrap (DO NOT EDIT; pertinent to both): FOUNDER_SESSION_BOOTSTRAP.md"
for f in CLAUDE.md STATUS.md TASKS.md roadmap/MANIFEST.md ROADMAP.md \
         .claude/rules/standing-directives.md mu/docs/agents/AgentRunbook.v0.md; do
  if [ -e "$ROOT/$f" ]; then echo "  [present] $f"; else echo "  [MISSING] $f"; fi
done
echo "  Claude memory index (Claude only): ~/.claude/projects/<proj>/memory/MEMORY.md"
echo "  Canonical for the imperatives below: .claude/rules/standing-directives.md (Claude) +"
echo "    memory feedback_standing_session_directives. Codex: use the enumeration below + FOUNDER_SESSION_BOOTSTRAP.md."
echo
echo "--- STANDING IMPERATIVES (founder; ALWAYS in force; canonical = standing-directives.md) ---"
cat <<'IMP'
 1. POLYMORPHIC ROLE CONFIG (runtime switch): the founder assigns which LLM plays each pipeline role,
    in ANY combination, and changes it at will. Roles include the ORCHESTRATOR (interactive session +
    pager/tmux/autoping), IMPLEMENTER (phase A/B), REVIEWER (bridge), SUPERVISOR (pre-commit / post-merge),
    and the derived COMMIT / BOT-REMEDIATION / DIALECTIC backends. Any role may be claude, codex, or another
    provider. The live executor_config.json (role_agents + derived backends + bridge_reviewers) and the live
    orchestrator mode are AUTHORITATIVE -- NEVER hardcode or assume a provider; verify live every time.
 2. SWITCHES: roles -> set_roles.py --implementer <X> --reviewer <Y> (the two top-level knobs; they DERIVE
    the executor/supervisor/bot-remediation/dialectic/commit backends + bridge_reviewers; commit to dev so
    pipeline waves, which run off dev, inherit the choice). Orchestrator -> set_orchestrator_mode.py
    --mode <claude|codex> --apply (ensure a fresh DISTINCT monitor for the active mode). Respect/verify the
    active config; never force a particular provider.
 3. Cron ON: 8-min identity+self-drive cron AND this hourly protocol cron. Don't skip preflight steps.
 4. PIPELINE-ONLY, BUILDERS-ONLY (never manual): ALL commits/pushes/merges/conflict-resolution go through the
    pipeline. Commit via builders (build_commit_handoff) + commit_executor; run waves via launch_wave + dispatcher;
    use standalone pipeline functions ONLY when needed (usually the WHOLE pipeline). NEVER manual git; NEVER
    hand-author receipts / handoffs / tracker notes / control packets (the builders produce them). RUN PARALLEL
    PIPELINE LANES whenever available (disjoint file-ownership; run serial only while the bridge-lock collision is
    unfixed). Worktree only (never the main repo); nohup so waves survive session end; MCP SQLite for bridge.db.
 5. ANY issue / pipeline break -> you MAY manually unblock the immediate item ONCE, but you MUST ALSO land a
    MANDATORY structural fix (a new script/builder, or a fix to the broken builder/launcher/recovery/commit/
    pre-commit surface) THROUGH THE PIPELINE so the failure mode never recurs; it may fold into a current wave
    that can carry it. A manual-only fix is a defect.
 6. Autonomous, non-interactive: do NOT stop unless you ABSOLUTELY need a genuine founder decision; never
    end a turn without a running task or a confirmed cron (avoid stalls).
 7. MOST STRUCTURAL always (especially when working on Mu structure): choose the most robust structural option
    even at larger blast radius (split into narrower waves if needed). NEVER add host semantics or new
    host-authority sites (ratchets enforce); structural conversion belongs in Mu/projections, not host code.
    Prefer structural reductions + parity-preserving boundary tightening; treat host-only fixes as SUSPECT.
    Destination = self-hosting / meta-circular Mu; Python/JS are bootstrap scaffolding only.
 8. Strict adherence: CLAUDE.md, STATUS.md/TASKS.md (when not stale), MEMORY.md, all .claude/rules/ incl.
    persona. The founder's live instructions OVERRIDE any contradiction (patched to congruence).
 9. Working repo + PRs are NEVER behind dev: preflight Step 0 ff-syncs the working branch (pull-only, when
    clean); structural priority wave: commit_executor/launch_wave auto-update primary worktree + feature
    branches to dev; behind-dev/dirty PR -> bounded pipeline conflict-refresh wave, never manual rebase.
10. EDIT OWNERSHIP (cross-orchestrator). Both orchestrators have READ-ONLY access to ALL config for full
    context, but EDIT only their own:
      - Claude EDITS: CLAUDE.md, MEMORY.md (+ ~/.claude memory), .claude/rules/, .claude/skills/, .claude/hooks/.
        Claude NEVER edits FOUNDER_SESSION_BOOTSTRAP.md (codex-owned) -- read-only.
      - Codex EDITS: FOUNDER_SESSION_BOOTSTRAP.md (+ ~/.codex/ config). Codex NEVER edits CLAUDE.md, MEMORY.md,
        or .claude/ claude-only files -- read-only.
      - BOTH: FOLLOW the shared/general info in the other's files; DISREGARD the other orchestrator's
        provider-SPECIFIC mechanics (claude ignores codex-specifics; codex ignores claude-specifics).
      - Shared repo code (mu/, tests, tooling incl. this script) is edited ONLY via the pipeline, never hand-edited.
IMP
echo
echo "--- KEY COMMANDS (run via pipeline/builders; <X>,<Y>,<mode> are founder-chosen providers) ---"
echo "  roles:        python3 mu/tools/executors/set_roles.py --implementer <X> --reviewer <Y>"
echo "  orchestrator: python3 mu/tools/session/set_orchestrator_mode.py --mode <mode> --apply"
echo "  launch wave:  python3 mu/tools/executors/launch_wave.py <config.json> --repo-root <WT> --bus-dir .agent_bus-laneN --launch"
echo "  commit:       build_commit_handoff (builder) -> python3 mu/tools/executors/commit_executor.py --standalone --handoff <json> --bus-dir <bus>"
echo "  preflight:    Claude: /preflight   Codex: tools/session/founder_session_guard.sh / tools/session/check_codex_startup_state.py"
echo
echo "--- VERIFY (read-only; reports the CURRENT live role/orchestrator config; asserts NO specific provider) ---"
python3 "$ROOT/mu/tools/executors/set_roles.py" --show 2>/dev/null | grep -iE 'CURRENT role_agents|derived backends|bridge_reviewers|EFFECTIVE' | sed 's/^/  config(live): /' || echo "  config: (set_roles --show unavailable)"
MODE=$(python3 -c "import json,os;p='$ROOT/.agent_bus/observability/orchestrator_mode.json';print(json.load(open(p)).get('mode','') if os.path.exists(p) else '')" 2>/dev/null)
echo "  orchestrator mode (live): ${MODE:-<unset>}"
git -C "$ROOT" fetch origin dev >/dev/null 2>&1 || true
BEHIND=$(git -C "$ROOT" rev-list --count HEAD..origin/dev 2>/dev/null || echo "?")
echo "  behind dev: ${BEHIND} (target 0; if >0 and clean, ff-sync; if dirty, commit pending work via pipeline first)"
echo "  branch: $(git -C "$ROOT" rev-parse --abbrev-ref HEAD 2>/dev/null)"
echo "================= END RCX SESSION PROTOCOL ================="
