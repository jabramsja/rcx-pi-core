# #8 — bridge-lock bounded-wait: scoping note (NON-BLOCKING, deferred to fresh-session rigor)

**Filed:** 2026-06-29. **Why deferred:** read-decided (dev `meta_bridge_supervisor.py`) — highest blast radius (the single-supervisor bridge lock; a mis-judged stale-clear → two concurrent supervisors → bridge-state corruption), net-new logic, and 2 prior attempts failed. The collision is RARE + recoverable, so this is low-urgency. Run heavy claude waves SERIAL until it lands.

## The problem (2026-06-21 learning)
`_MetaBridgeLock.__enter__` (`meta_bridge_supervisor.py:337`) does `fcntl.flock(self._fp, fcntl.LOCK_EX | fcntl.LOCK_NB)` (`:342`) — **non-blocking** — and on contention raises `MetaBridgeError` **immediately** (`:343-350`), with NO retry, NO bounded-wait, NO stale-holder probe. So a 2nd concurrent wave's bridge fails instantly ("Another meta-bridge supervisor is running") instead of waiting/serializing.

## The fix (net-new — verified by reading __enter__)
Three parts, all at the `_MetaBridgeLock` layer (this is slice (i); slice (ii) = threading the caller budget, deferred):
1. **Add the holder PID to the lock metadata.** `_lock_metadata_payload` (`:79-81`) currently writes `"holder": "meta_bridge_supervisor"` — a constant string, **no PID**. A contender cannot probe live-vs-dead without it. Add `os.getpid()` (and a start-time/boot-id if you want PID-reuse safety).
2. **Bounded-wait acquire.** Replace the immediate-raise with a loop: `LOCK_EX|LOCK_NB` + short backoff (e.g. 0.25s) up to a timeout.
3. **Stale-holder clear on timeout.** On timeout, read the metadata holder PID and `os.kill(pid, 0)` it: if **dead** (ProcessLookupError), the holder crashed without releasing → clear + acquire; if **alive**, raise (genuine contention).

## CRITICAL risk (why fresh rigor)
The stale-clear is the danger: if the PID-probe wrongly judges a LIVE holder as dead and clears its lock, two supervisors run concurrently and corrupt bridge state (the exact thing the lock prevents). The probe MUST be conservative (PID-reuse-safe: match PID **and** a start-time/boot-id, not PID alone; fail toward "assume alive / don't clear" on any ambiguity).

## Prior failures (do not repeat)
- **v1 (PR #1145, closed):** used a fixed-600s `META_LOCK_WAIT_TIMEOUT_S` that exceeded the 30s caller `wait_for_lock_seconds`, hanging a slot ~10min. Lesson: the wait timeout must be SHORT (or the caller's budget), not a fixed-600s.
- **v2 (lane16, max_turns_reached):** tried to thread the caller budget through `run_meta_bridge` → `_MetaBridgeLock` across multiple call sites + bounded-wait + stale-holder in one pass — too big for 100 turns.

## Recommended slice for a fresh session
Slice (i) ONLY: parts 1-3 above at the `_MetaBridgeLock` layer, with a **short fixed timeout** (e.g. 30s, matching the typical caller budget — avoids v1's mismatch AND v2's cross-call-site threading). Slice (ii) (thread the real caller `wait_for_lock_seconds`) is a separate later wave if needed. Regression: two `_MetaBridgeLock` acquires — second waits then succeeds when the first releases; second clears + acquires when the first's PID is dead; second raises when the first's PID is alive past timeout. Use isolated tmp lock paths (not the live `.agent_bus/meta/meta_bridge.lock`).

## Land it like the supervisor-machinery waves
Self-referential (modifies the supervisor) → grep evidence_command + the #13/#19 bootstrap `commit_executor --standalone` self-protect if it strands. Note also: `_run_wave_evidence_with_restore` (`:1618`) wraps the same lock — a bounded-wait change interacts with the wave_evidence path (#15), so coordinate the two.
