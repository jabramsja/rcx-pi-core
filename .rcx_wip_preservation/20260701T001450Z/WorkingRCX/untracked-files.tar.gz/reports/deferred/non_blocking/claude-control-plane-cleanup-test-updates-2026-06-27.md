# Deferred (non-blocking): test updates required by the claude control-plane cleanup

Date: 2026-06-27
Wave: claude-control-plane-cleanup-2026-06-27
Classification: NON-BLOCKING for current dev (dev green-gate passes today); REQUIRED before the
claude control-plane cleanup can land. Resolution = the cleanup dispatcher wave (below), not ignored.

## Finding 1 — coinduction discoverability gate hard-codes a transient queue phrase
`mu/tests/l4_gates/test_coinduction_foundation_gate.py:77` (and the `mu/tests/docs/` copy):
`assert "Coinduction is the next active structural item" in tasks_text`.
Coinduction landed (PR #1164) and fixpoint (PR #1165) merged, so once TASKS.md queue-truth is corrected the
phrase is gone and the gate fails. dev passes today only because dev's TASKS.md still carries that phrase.
Why non-blocking now: dev green-gate is green (the phrase is present on dev); it only fails when a wave
corrects the queue truth. Required fix: the gate must verify discoverability robustly (the coinduction doc
exists + is referenced in `roadmap/MANIFEST.md` / named in TASKS.md), independent of the transient queue
position, so it cannot break when the queue advances.

## Finding 2 — commit-outcome-pager changes run_commit_pipeline's event sequence
Setting the commit_executor backend to claude (via `executor_common.py`) makes `run_commit_pipeline` emit
`commit_started`/`commit_failed` lifecycle events. Tests that assert the pre-commit pager event sequence
without those events then fail. VERIFIED a real change (not incidental): `git stash` the cleanup ->
`mu/tests/tools/test_executor_dispatch.py::TestSupervisorPackage::test_20b_phase_b_metadata_is_preserved_into_supervisor_package`
passes on clean dev; unstash -> it fails. Blast radius (files asserting commit-pipeline event sequences,
to verify + update under review): test_commit_outcome_pager_lifetime, test_executor_dispatch,
test_commit_executor_receipt, test_phase_b_executor, test_pipeline_agent_pager, test_phase_a_executor.
Required fix: update the affected event-sequence assertions to the commit-outcome-pager-on sequence
(do NOT drop the tests — that would hide the real change).

## Resolution (scheduled, not ignored)
Both are handled by the **claude control-plane cleanup dispatcher wave** (`launch_wave`, Phase-A/B review):
the implementer updates the affected event-sequence tests + the coinduction gate, with the reviewer verifying
the sequences/discoverability are correct. Recipe: `/tmp/handoff_commit_recipe.md`; diagnosis: learning.md
2026-06-27 PIPELINE entry. Until that wave lands, the config-only subset (no TASKS/STATUS doc edits) was the
attempted decoupling; the full cleanup waits on the dispatcher wave so these test surfaces are fixed under review.
