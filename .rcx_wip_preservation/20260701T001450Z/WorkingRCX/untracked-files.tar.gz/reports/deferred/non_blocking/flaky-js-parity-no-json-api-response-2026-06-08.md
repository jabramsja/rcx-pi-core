# NON-BLOCKING: JS-substrate parity gates failing in CI/pre-push (not local), unrelated to the wave

**Date:** 2026-06-08
**Classification:** NON-BLOCKING for wave correctness (fail-closed, verified) — but the recurrence is a real CI-reliability issue tracked in #57.
**Surfaced by:** #54 (wave-evidence-lock-propagate) — two consecutive runs, two *different* JS gates.

## Findings (two instances, both `tests/l4_gates/`, JS substrate)
1. **pre-push (attempt 1):** `test_nonlinear_rejection_parity_gate.py::TestNonlinearRejectionParityGate::test_js_run_vector_rejects_nonlinear_agree` → `RuntimeError: No JSON_API_RESPONSE` (node returned no JSON envelope). Passes standalone: `1 passed in 0.08s`.
2. **CI green-gate (re-run, PR #1083):** `test_p7w2_builtin_reduction_gate.py::TestRatchetEvidence::test_js_eval_step_passes` → `AssertionError` (`gh run view 27119760939 --log-failed`). Passes standalone: `1 passed in 1.69s`.

## Verified vs unverified
- **Verified (command output):** both tests pass standalone in the #54 worktree; both failed only inside the parallel CI/pre-push harness; #54 changes only Python/docs (`git diff --name-only origin/dev...HEAD` = `meta_bridge_supervisor.py`, `test_meta_bridge_supervisor.py`, `TASKS.md`, control packet, indicator) — **no** JS or `l4_gates` files.
- **Hypothesis (re-run in progress decides):** intermittent vs deterministic-CI-only. Green-gate re-run on the same commit (`gh run 27119760939 --failed`) is the discriminator — re-pass ⇒ intermittent; re-fail ⇒ deterministic CI-vs-local divergence. Not yet verified which.

## Pipeline impact — fail-closed verification
- These are L4 **gate tests** run by pre-push-fast + green-gate (a required check). A failure makes `commit_executor` exit `Status: error` and the PR's required green-gate go FAILURE → **no merge**. EVIDENCE: #54 attempt-1 `Status: error` (no PR); re-run created PR #1083 but green-gate=FAILURE, `mergedAt=null`, dev unchanged at `addf2151`.
- **Not fail-open:** `No JSON_API_RESPONSE`/`AssertionError` are hard failures (the gate FAILS), never a silent pass — a real JS↔Python parity violation cannot slip through. No silent-regression path.
- ⇒ Deferring carries no correctness risk (no bad merge); the cost is a blocked/retried merge.

## Why NON-BLOCKING for #54 specifically
- The failures are in JS-parity gates the #54 change does not touch (git diff), and pass standalone — #54's own correctness is independently proven (152 supervisor tests + local audit_fast green).

## Structural follow-up — #57 (escalated)
The recurrence (different gate each run, now hitting the *required* green-gate) means this can intermittently block ANY wave's merge. #57: make the node/JS-substrate parity invocation resilient (bounded retry on empty/`No JSON_API_RESPONSE` + investigate the CI-only `AssertionError` for env divergence). Do NOT skip the gates (that converts fail-closed → silent-regression risk).
