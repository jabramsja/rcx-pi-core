# Nightly slow_tests RED since 2026-06-26 — full-nightly-scale parallel/resource flakiness (NON-BLOCKING)

**Filed:** 2026-06-29 (task #10 triage). **Classification:** NON-BLOCKING — the nightly `slow_tests.yml` is informational; it does NOT gate commits/merges (the required green-gate passes, and 5+ PRs merged cleanly through it this session). It does, however, leave dev's nightly red and must not be ignored.

## Symptom
`slow_tests.yml` (nightly, `-m l4_expensive`, parallel/xdist, ×3 retries) has been RED for 3 days:
- 28327919852 (2026-06-28) — failure
- 28294255343 (2026-06-27) — failure
- 28252650237 (2026-06-26) — failure
- 28187056273 (2026-06-25) — **success** (last green)

`gh run view 28327919852 --log-failed` tally: **119 AssertionError** + 5 JSON_API_RESPONSE; **0** ENOENT/seed_loader/MetaBridgeError/"Repo state changed". Broad across cross-substrate parity + structural tests: test_js_parity_automated (302 hits), test_hemisphere_adversarial (198), test_hemisphere_routing (84), test_bootstrap_primitives (74), test_recurrence_parity (56), test_match_bridge_invariants (52), ...

## Triage — three hypotheses tested by RUNNING THE FLOW (all refuted except the last)
1. **#57-style node/seed race** — REFUTED: 0 ENOENT/seed_loader/MetaBridgeError in the failed log (those are the #57 signatures); this is AssertionError, a shared-state *value* divergence, not a missing-file race.
2. **Deterministic Stage-4-cutover parity regression** (the 06-25→06-26 window changed the substrate via the Stage 4 matcher cutover #1153 + f3332f18, and memory `reference_stage4_counter_numeral_boundary` notes the JS mirror was deferred) — **REFUTED by running the test**: `pytest mu/tests/parity/test_js_parity_automated.py::TestDifferentialReplayAuditR3` = **96 passed in 133.62s SERIALLY on dev** (lane2 @ 2da83d93, which has the cutover). The parity tests PASS on dev → not a deterministic regression. (The bisect+memory chain was circumstantially compelling but wrong — a cautionary case for run-the-flow-before-root-causing.)
3. **Simple 2-test parallel race** (parity test + the wave-evidence/REPO_ROOT suspect `test_meta_bridge_supervisor`) — REFUTED: `pytest <parity class> mu/tests/tools/test_meta_bridge_supervisor.py -n auto` = **251 passed in 97.47s**. No small-set race.

**Conclusion:** the failures do NOT reproduce serially OR in small parallel sets — they need the **full l4_expensive suite under the nightly's xdist worker count**. This is **full-nightly-scale parallel/resource flakiness**, NOT a code regression. Most plausible trigger: the 06-26 waves (surreals #1158 / stage4) **added many slow `run_mu` tests**, pushing the nightly's parallel run past a resource/contention threshold.

## Actionable next step (the real fix — a substantial follow-up, not a tail-of-night step)
Reproduce the full nightly locally: run the complete `-m l4_expensive` suite under the nightly's exact xdist worker count (`-n <nightly N>`) to reproduce the mass AssertionErrors; then either (a) lower the nightly worker count / add per-test resource isolation, (b) bisect to a specific high-parallelism shared-state contention and isolate it, or (c) split the nightly into smaller shards. Do NOT chase a Stage-4 JS-mirror or a #15 wave-evidence fix for this — both were refuted.

## Evidence commands (reproducible)
- `gh -R jabramsja/rcx-pi-core run list --workflow slow_tests.yml --limit 4`
- `gh -R jabramsja/rcx-pi-core run view 28327919852 --log-failed | grep -aoE 'AssertionError|ENOENT|seed_loader' | sort | uniq -c`
- `cd <dev worktree> && PYTHONHASHSEED=0 python3 -m pytest mu/tests/parity/test_js_parity_automated.py::TestDifferentialReplayAuditR3 -x -q` → 96 passed (serial, on dev)
