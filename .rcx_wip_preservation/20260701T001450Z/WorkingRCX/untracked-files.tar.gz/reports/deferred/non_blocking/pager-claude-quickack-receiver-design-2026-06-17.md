# Pager Claude leg — quick-ack receiver design (2026-06-17)

DOC_STATUS: DESIGN_NOTE (planning artifact for a multi-wave pipeline build; not a state file)

## Problem (verified)
The pipeline pager `mu/tools/observability/pipeline_agent_pager.py` claude leg `_dispatch_claude`
(~:1661) runs a FULL `claude --resume <monitor> -p <event>` (or fresh `claude -p`) via
`subprocess.run(..., timeout=timeout_s)` where `timeout_s` is only the ~10–20s remaining slice of the
pager dispatch budget (config claude_ack 20 / trigger 30). A real opus-4-8 turn far exceeds that, so it
is killed every time → `last_error: "claude pager submission timed out after ~10–20s"`,
`acknowledged: false`, claude never in `delivered_targets`. Verified in the lane3 pager state:
26 consecutive claude timeouts; codex leg delivers fine. So the pager does NOT reliably notify the
Claude side — the 8-min cron is what actually re-invokes the orchestrator.

Codex works because it posts to a persistent `codex app-server --listen` loopback-ws daemon
(`_codex_app_server_exchange` ~:1119, started by `check_codex_startup_state._start_codex_app_server`
~:2694, tmux `rcx-codex-app-server`) that ACKS receipt fast while codex processes async.

## Founder decision
Quick-ack channel (most robust): fast receipt confirmation, model responds async — mirror the codex
app-server pattern. Pager and autoping MUST stay SEPARATE mechanisms (founder, repeated).

## Hardened design (advisor-reviewed)
- **Transport: a file-queue reusing the existing `pending_targets` state**, NOT a new socket/HTTP
  listener. Atomic enqueue = the quick-ack (same class as codex's "turn accepted, not complete" ack).
- **Two-phase state (corrects the naive "delivered-on-enqueue"):** on enqueue mark an in-state
  `accepted_async` (the quick-ack); write the DURABLE receipt / `delivered_targets[claude]` ONLY when
  the async claude turn exits 0; keep a separate delivery-outcome record that RE-QUEUES on failure.
  Rationale: receipts rebuild `delivered_targets` on reconcile (~:808-825), so marking delivered on
  enqueue would mask async failures forever and block re-queue.
- **Daemon: a small SEPARATE `tools/session/claude_pager_receiver.py`** (its own process, per-bus like
  autoping), sharing the autoping watcher's drain primitives (`claude_autoping_watch.py` ~:133-221,
  ~:372-470, ~:610-771) via an EXTRACTED shared helper (no code duplication; processes stay separate).
- **Delivery:** serialized (one turn at a time, no pile-up), GENEROUS per-delivery timeout (~120s),
  `start_new_session` + terminate-process-group + reaper so a hung claude turn can't wedge the daemon.
  Use `_claude_dispatch_env()` (RCX_PIPELINE_SESSION=1, RCX_CLAUDE_MONITOR unset) so delivery never
  clobbers `orchestrator_session_id` / `claude_monitor_session_id`.
- **Target — DECIDED (founder 2026-06-17): FRESH DIRECT `claude -p` ONLY.** The pager pages Claude
  directly with a fresh acting subprocess ("paged directly from the pipeline"), fully SEPARATE from the
  autoping's monitor session. The pager leg DROPS the monitor-resume path entirely (the dedicated-monitor
  refactor's monitor-resume is the part timing out). A fresh `claude -p` already never resumes the live
  orchestrator, so the non-interference guarantee holds without touching any session. Consequence: the
  pager no longer reads `claude_monitor_session_id` and no longer shares any session/primitives with the
  autoping — full pager≠autoping separation. (The monitor session remains the autoping's alone.)
- **Idempotency:** by `event_id` then `transition_key`.
- **Receiver down:** fail-open — leave the target pending (retryable), exactly as today; no regression.
- **Pager change:** `_dispatch_claude` posts to the receiver (enqueue, fast ack → `accepted_async`)
  instead of blocking on a full turn in the ~10–20s budget.

## Invariant fences (packet MUST state)
Never resume the live orchestrator; never clobber the session-id files (use `_claude_dispatch_env`);
preserve the monitor-equals-live fallthrough; leave the codex leg untouched; pager and autoping remain
separate processes; observability/control-surface only (no runtime/substrate files); fail-open;
durable receipt only on turn-complete.

## Wave split (fit implementer turn budget; 3 L4_ENABLER waves)
Simplified by the fresh-`claude -p` target decision: the receiver is SELF-CONTAINED (file-queue drain +
fresh `claude -p` delivery + reaper + outcome record) and does NOT need to share the autoping's
monitor-resume primitives — so no extraction wave is required.
1. New DORMANT `tools/session/claude_pager_receiver.py`: file-queue drain loop + fresh `claude -p`
   delivery (serialized, ~120s, start_new_session + process-group reaper, `_claude_dispatch_env`) +
   outcome record (exit-0 → success, else re-queue) + idempotency (event_id/transition_key) + unit
   tests. No pager behavior change yet.
2. Pager quick-ack: `_dispatch_claude` enqueues to the receiver's file-queue + marks `accepted_async`
   (drop the monitor-resume + blocking-subprocess path); two-phase accepted_async→durable-receipt-on-
   exit-0; fail-open if receiver down (leave pending); regression tests for enqueue/accepted/delivered
   semantics + the no-monitor-resume invariant.
3. Preflight health-start + orphan sweep + SKILL.md doc (per-bus, nohup/setsid; mirror the codex
   app-server step-14d block).

## Cited current-behavior facts (advisor, file:line)
pipeline_agent_pager.py: claude leg blocks/times out ~:1661-1735; codex quick-acks turn-accepted
~:1119-1155, ~:1507-1542; `_claude_dispatch_env` clobber guard ~:1627-1658; emit dispatches inline +
retries pending ~:707-717, ~:2048-2050; receipts rebuild delivered_targets ~:808-825, ~:1874-1881;
pager per-bus vs shared codex daemon ~:1957, ~:2083. claude_autoping_watch.py drain primitives
~:133-221, ~:372-470, ~:610-771. check_codex_startup_state.py daemon lifecycle ~:2694-2743, ~:3208-3233.
