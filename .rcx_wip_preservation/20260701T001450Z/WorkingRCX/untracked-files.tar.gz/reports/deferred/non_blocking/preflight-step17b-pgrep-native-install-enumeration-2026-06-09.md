# Deferred (NON-BLOCKING): preflight step-17b cannot enumerate the claude process on this native install

- **Date:** 2026-06-09
- **Classification:** NON-BLOCKING (fail-safe — a missing warning, never a wrong action)
- **Surface:** `.claude/skills/preflight/SKILL.md` step 17b (session-binary staleness detection)
- **Found by:** preflight run this session (the step printed "live claude processes:" with an empty list)

## Symptom

Step 17b enumerates live claude processes to warn when a session is running a
pre-patch in-memory binary (Node v8 loads the bundle once at `exec()`; on-disk
patches only take effect on the next fresh launch). On this box the enumeration
loop produced **zero** PIDs even though a claude session is plainly running.

## Diagnosis (commands + evidence, 2026-06-09)

```
$ ps -axo pid,command | grep -i claude | grep -v grep
97831 claude --dangerously-skip-permissions --append-system-prompt-file /Users/jeffabrams/.claude/hard-rules.txt

$ pgrep -f '(^|/)claude( |$)'        # the SKILL step-17b pattern
(no match)

$ pgrep -f 'claude'                  # even a bare substring
(no match)

$ readlink ~/.local/bin/claude
/Users/jeffabrams/.local/share/claude/versions/2.1.170
```

`ps -axo command | grep claude` reliably finds PID 97831, but **`pgrep -f`
matches nothing** — and it is *not* the regex, because bare `pgrep -f 'claude'`
also returns empty. `pgrep -f` does not match the claude command line on this
macOS native install.

## Root cause

Step 17b's process loop is `for PID in $(pgrep -f '(^|/)claude( |$)')`. With
`pgrep -f` returning an empty set on this platform, the loop body never runs, so
`STALE_COUNT` stays 0 and the step always prints
`"Session-binary staleness: clean (0 live claude processes...)"`. The staleness
check is therefore **non-functional on this install layout** — it can never warn
about a stale in-memory binary, which is the one thing it exists to do.

## Why NON-BLOCKING

The step is explicitly **warn-only** ("Warn only — do not kill or restart
processes"). Its silent no-op produces a *missing warning*, not an incorrect
action: no merge, pipeline, or correctness path depends on it. This session's
actual staleness question was answered by timestamps instead (session first
activity 21:12 > binary repatch mtime 19:36 → this process exec'd the patched
binary), so no operational gap resulted.

## Proposed fix (when the preflight SKILL is next refreshed)

Replace the `pgrep -f` enumeration with a `ps`-based one that works on this
layout, preserving warn-only semantics:

```bash
ps -axo pid,lstart,command 2>/dev/null \
  | grep -E '(^|/| )claude( |$|--)' | grep -v grep
# then parse PID (field 1) + lstart for the start-time-vs-binary-mtime compare
```

Keep the `SELF_CC_PID` walk and the "warn only" output; only the
process-enumeration primitive needs to change (`pgrep -f` → `ps | grep`).

## Related preflight-SKILL drift (same class, separate item)

Step 19 (binary-patch verifier) is hardcoded to **v2.1.114** function names
(`yf8`/`_4`/etc.) and "67 active patches". The live binary is **v2.1.170**
(61 patches per `reference_tweakcc_repatch.md`, verified 61/61 on 2026-06-09), so
the step-19 grep would emit false MISSING/PRESENT if run as written. Authoritative
verification is the reference file + version stability. Both 17b and 19 are
preflight-SKILL version drift; a single SKILL refresh pass should address them
together.
