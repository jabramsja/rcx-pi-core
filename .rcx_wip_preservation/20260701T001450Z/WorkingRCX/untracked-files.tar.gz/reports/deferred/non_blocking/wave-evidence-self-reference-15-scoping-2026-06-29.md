# #15 — wave_evidence self-reference isolation: scoping note (NON-BLOCKING, deferred to fresh-session rigor)

**Filed:** 2026-06-29. **Why deferred:** evidence-based verdict (read the machinery on dev `9063a224`) — high-complexity + highest blast radius (the pre-commit/post-merge supervisor commit gate). Needs a reproduction of the exact missed mutation + a careful isolation design; not a tail-of-session launch. The grep-evidence workaround (below) is the interim mitigation and works.

## The problem (recurring this session: #13 / #19 hand-finishes)
A wave that MODIFIES supervisor machinery (recovery_gate / commit_executor / meta_bridge_supervisor / phase_b_executor) and uses a **pytest** evidence_command strands the meta-review with `ERROR_REPO_CHANGED: "Repo state changed during meta-review"`, because the pytest re-invokes the supervisor and leaves a working-tree mutation. **Interim workaround (proven):** use a NON-re-entrant **grep** evidence_command (`grep -q 'def test_<marker>' <file>`) so the evidence proves the fix present without re-entering the supervisor; the full pytest runs in CI green-gate. Used on #13 and #19 this session.

## The machinery (read on dev 9063a224, `mu/tools/agents/meta_bridge_supervisor.py`)
Two distinct repo-state checks:
1. **wave_evidence restore** — `_run_wave_evidence_with_restore_unlocked` (`:1522`), under `_MetaBridgeLock` (`:1618`). Already sophisticated: `compute_repo_state` (`:618`) before; snapshot tracked (`git ls-files`) + untracked (`ls-files --others --exclude-standard`) + git index into a tmpdir; run the evidence via `run_validation_command(["bash","-c",cmd])`; FINALLY restore index + tracked + remove evidence-created-untracked + restore untracked + remove created empty dirs; then a **post-restore** check (`:1600`) `post_restore_state != pre_evidence_state` → returns `(1, "evidence restore failed: repo state changed after restore")`.
2. **meta-review-level** — `run_meta_bridge*` captures `state_start` before the review and `state_end = compute_repo_state(repo_root)` at `:3846`; `if state_start.state_sha != state_end.state_sha:` → `ERROR_REPO_CHANGED` "Repo state changed during meta-review" (`:3847-3855`).

If the wave_evidence restore were perfect, check (2) would pass (the evidence's mutations are reverted). So the self-referential trip means **the restore is not covering some mutation the self-referential pytest makes** (per #13: "working-tree MM vs index"). Candidate causes (UNVERIFIED — reproduce first): the NESTED supervisor run the pytest triggers writes outside the snapshot scope; or a gitignored artifact (`.agent_bus/`, bytecode) that `compute_repo_state` hashes but `ls-files`-based snapshot misses; or a lock/ordering interaction with the nested `_MetaBridgeLock`.

## Next steps (fresh session)
1. **Read `compute_repo_state` (`:618`)** — what does `state_sha` hash? tracked+staged+unstaged+untracked only, or gitignored too? This determines whether a gitignored nested-run artifact is the trip.
2. **Reproduce** — launch (or simulate) a wave modifying `recovery_gate.py` with a `pytest test_recovery_gate.py` evidence_command; capture the exact `state_start → state_end` diff (which path/file changed).
3. **Design the isolation** — three candidate approaches: (a) run a self-referential evidence_command in a separate git clone/worktree (full isolation, heaviest); (b) detect re-entrancy (a nested supervisor invocation) and scope check (2) to ignore the nested run's footprint; (c) extend the restore to cover the exact missed mutation found in step 2 (lightest if the miss is a known class). Pick by the step-2 evidence.
4. Add the regression in `mu/tests/tools/test_meta_bridge_supervisor.py` (use a per-test isolated tmp git repo — see the #57/PR #1087 precedent, NOT live REPO_ROOT).

## Blast radius / caution
This is the commit gate — a wrong fix could allow un-verified commits OR break the repo-state safety for ALL waves. Land it like #19 (the fix can't validate through itself → bootstrap `commit_executor --standalone` self-protect; grep evidence). Until then, supervisor-machinery waves keep using a grep evidence_command (the workaround is reliable).
